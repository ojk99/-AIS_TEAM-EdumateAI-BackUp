// ==============================================================================
// [EduMate AI - 초등사회] 2022 개정 교육과정 전 학년 대규모 문제은행 데이터베이스 (총 270문항)
// 학년군별 90문항 구성: OX 퀴즈 30개, 4지선다 30개, 단답형 20개, 서술형 10개
// ==============================================================================

const SOCIAL_QUESTION_BANK_ALL = [
  // ============================================================================
  // [1] 초등학교 1~2학년군 (총 90문항: OX 30, 객관식 30, 단답형 20, 서술형 10)
  // ============================================================================
  // --- 1~2학년군 OX 퀴즈 (30문항) ---
  {
    id: "g12_ox_01", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "수업 시간에 발표하고 싶을 때는 손을 들고 선생님이 이름을 부르면 말해야 해요.",
    options: [], answer: "O", explanation: "맞아요! 친구들의 말을 끊지 않고 손을 든 뒤 차례를 기다려야 해요."
  },
  {
    id: "g12_ox_02", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "친구와 다투었을 때는 '미안해'라고 먼저 사과하는 것보다 계속 화를 내는 것이 좋아요.",
    options: [], answer: "X", explanation: "틀려요! 친구의 마음을 이해하고 먼저 '미안해'라고 사과해야 사이좋게 지낼 수 있어요."
  },
  {
    id: "g12_ox_03", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "복도나 계단에서는 뛰지 않고 오른쪽으로 조용히 걸어 다녀요.",
    options: [], answer: "O", explanation: "맞아요! 복도에서 뛰면 마주 오는 친구와 부딪혀 다칠 수 있으니 우측통행을 해야 해요."
  },
  {
    id: "g12_ox_04", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "학교 도서관에서는 큰 소리로 노래를 부르고 떠들어도 괜찮아요.",
    options: [], answer: "X", explanation: "틀려요! 도서관은 책을 읽는 공공장소이므로 쉿! 조용히 해야 해요."
  },
  {
    id: "g12_ox_05", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "선생님이나 어른을 만났을 때는 허리를 굽혀 공손하게 인사해요.",
    options: [], answer: "O", explanation: "맞아요! 인사는 서로를 존중하고 반가운 마음을 전하는 바른 예절이에요."
  },
  {
    id: "g12_ox_06", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "놀이터의 미끄럼틀을 탈 때는 거꾸로 기어올라가서 타야 안전해요.",
    options: [], answer: "X", explanation: "틀려요! 미끄럼틀은 계단으로 올라가서 바르게 앉아 내려와야 다치지 않아요."
  },
  {
    id: "g12_ox_07", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "수업이 끝난 후 내가 사용한 자리와 책상은 깨끗하게 스스로 정리해요.",
    options: [], answer: "O", explanation: "맞아요! 자기가 사용한 물건과 쓰레기는 스스로 정리하는 것이 멋진 학생의 습관이에요."
  },
  {
    id: "g12_ox_08", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "친구가 어려움에 처했을 때는 모른 척 지나가는 것이 바른 행동이에요.",
    options: [], answer: "X", explanation: "틀려요! 곤란한 친구를 보면 '도와줄까?' 하고 따뜻하게 손을 내밀어야 해요."
  },
  {
    id: "g12_ox_09", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "급식을 먹을 때는 줄을 서서 차례대로 음식을 받아요.",
    options: [], answer: "O", explanation: "맞아요! 질서를 지키며 차례대로 줄을 서야 안전하고 기분 좋게 식사할 수 있어요."
  },
  {
    id: "g12_ox_10", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "ox", difficulty: "하", base_score: 1,
    question: "학교에서 몸이 아프거나 다치면 참지 말고 선생님께 바로 말씀드려야 해요.",
    options: [], answer: "O", explanation: "맞아요! 선생님께 말씀드리고 보건실에 가서 바로 치료를 받아야 해요."
  },
  {
    id: "g12_ox_11", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "여름에는 날씨가 매우 덥기 때문에 두꺼운 털스웨터를 입어야 해요.",
    options: [], answer: "X", explanation: "틀려요! 여름에는 땀이 잘 마르고 얇고 시원한 반소매 옷을 입어요."
  },
  {
    id: "g12_ox_12", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "봄에는 날씨가 따뜻해지며 개나리와 진달래, 벚꽃이 활짝 피어요.",
    options: [], answer: "O", explanation: "맞아요! 봄은 만물이 소생하며 예쁜 꽃들이 피어나는 계절이에요."
  },
  {
    id: "g12_ox_13", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "가을에는 벼가 황금빛으로 익고 나뭇잎이 울긋불긋 단풍으로 물들어요.",
    options: [], answer: "O", explanation: "맞아요! 가을은 곡식과 과일이 무르익고 단풍이 아름다운 수확의 계절이에요."
  },
  {
    id: "g12_ox_14", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "겨울철에 눈이 많이 오면 미끄러우므로 뛰지 말고 조심해서 걸어야 해요.",
    options: [], answer: "O", explanation: "맞아요! 눈길이나 얼어붙은 빙판길은 미끄러지기 쉬워 천천히 걸어야 안전해요."
  },
  {
    id: "g12_ox_15", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "수박과 참외는 눈사람을 만드는 추운 겨울에 주로 수확하는 과일이에요.",
    options: [], answer: "X", explanation: "틀려요! 수박과 참외는 무더운 여름철에 땀을 식혀주는 대표적인 여름 과일이에요."
  },
  {
    id: "g12_ox_16", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "겨울에 외출할 때는 장갑, 목도리, 털모자를 쓰면 체온을 지킬 수 있어요.",
    options: [], answer: "O", explanation: "맞아요! 목과 손, 머리를 따뜻하게 감싸면 감기를 예방할 수 있어요."
  },
  {
    id: "g12_ox_17", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "비가 오는 날에는 운전자가 나를 잘 볼 수 있도록 밝은색 우산을 쓰는 것이 좋아요.",
    options: [], answer: "O", explanation: "맞아요! 노란색이나 투명한 밝은 우산을 써야 시야를 가리지 않고 안전해요."
  },
  {
    id: "g12_ox_18", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "우리나라는 봄, 여름, 가을, 겨울의 사계절이 뚜렷한 나라예요.",
    options: [], answer: "O", explanation: "맞아요! 우리나라는 계절마다 날씨와 풍경이 달라지는 아름다운 사계절이 있어요."
  },
  {
    id: "g12_ox_19", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "경찰관 아저씨는 마을의 범죄를 막고 길을 잃은 어린이를 도와주세요.",
    options: [], answer: "O", explanation: "맞아요! 경찰관님은 우리 마을의 질서와 안전을 지켜주시는 고마운 분들이에요."
  },
  {
    id: "g12_ox_20", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "편지나 택배를 다른 지역으로 보내려면 소방서에 가야 해요.",
    options: [], answer: "X", explanation: "틀려요! 우편물이나 택배를 보낼 때는 우체국으로 가야 해요."
  },
  {
    id: "g12_ox_21", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "환경미화원분들 덕분에 우리 마을 골목길이 매일 깨끗하게 유지돼요.",
    options: [], answer: "O", explanation: "맞아요! 이른 아침부터 쓰레기를 치워주시는 분들 덕분에 마을이 쾌적해요."
  },
  {
    id: "g12_ox_22", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "놀이터나 공원의 벤치에는 쓰레기를 버리고 가도 청소하는 사람이 있으니 괜찮아요.",
    options: [], answer: "X", explanation: "틀려요! 내가 만든 쓰레기는 쓰레기통에 넣거나 집으로 가져가야 해요."
  },
  {
    id: "g12_ox_23", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "이웃집 사람을 엘리베이터에서 마주치면 밝은 미소로 '안녕하세요' 인사해요.",
    options: [], answer: "O", explanation: "맞아요! 이웃 간의 다정한 인사는 사이좋은 마을을 만드는 첫걸음이에요."
  },
  {
    id: "g12_ox_24", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "시장에서 물건을 살 때는 돈을 내지 않고 그냥 가져와도 돼요.",
    options: [], answer: "X", explanation: "틀려요! 상점에서 물건을 살 때는 정해진 가격만큼 돈을 바르게 지불해야 해요."
  },
  {
    id: "g12_ox_25", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "ox", difficulty: "하", base_score: 1,
    question: "횡단보도의 보행자 신호등이 빨간불일 때는 멈추고 기다려야 해요.",
    options: [], answer: "O", explanation: "맞아요! 빨간불은 멈춤 신호이므로 초록불로 바뀔 때까지 인도에서 기다려요."
  },
  {
    id: "g12_ox_26", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "ox", difficulty: "하", base_score: 1,
    question: "자동차를 탈 때는 뒷좌석이라도 반드시 안전띠를 매야 해요.",
    options: [], answer: "O", explanation: "맞아요! 전 좌석 안전띠 착용은 갑작스러운 충격으로부터 생명을 지켜줘요."
  },
  {
    id: "g12_ox_27", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "ox", difficulty: "하", base_score: 1,
    question: "모르는 사람이 맛있는 과자를 주며 '따라오라'고 하면 신나서 따라가야 해요.",
    options: [], answer: "X", explanation: "절대 안 돼요! 낯선 사람이 유혹할 때는 '싫어요! 안 돼요!' 하고 큰 소리로 외치며 도망쳐야 해요."
  },
  {
    id: "g12_ox_28", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "ox", difficulty: "하", base_score: 1,
    question: "집안에서 불이 났을 때는 젖은 수건으로 코와 입을 막고 자세를 낮춰 대피해요.",
    options: [], answer: "O", explanation: "맞아요! 유독가스를 마시지 않기 위해 젖은 수건으로 가리고 낮게 엎드려 대피해야 해요."
  },
  {
    id: "g12_ox_29", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "ox", difficulty: "하", base_score: 1,
    question: "비가 오거나 눈이 올 때는 횡단보도 위에서 스마트폰 게임을 보며 걸어요.",
    options: [], answer: "X", explanation: "틀려요! 보행 중 스마트폰을 보면 주변 위험을 보지 못해 큰 교통사고가 날 수 있어요."
  },
  {
    id: "g12_ox_30", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "ox", difficulty: "하", base_score: 1,
    question: "가족 구성원은 서로를 사랑하고 힘들 때 도우며 소중히 아껴주어야 해요.",
    options: [], answer: "O", explanation: "맞아요! 가족은 세상에서 가장 따뜻한 보금자리이며 서로 사랑하고 배려해야 해요."
  },

  // --- 1~2학년군 객관식 (30문항) ---
  {
    id: "g12_mc_01", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "수업을 시작할 때 반장이나 선생님과 함께 나누는 첫인사는 무엇일까요?",
    options: ["잘 가라, 친구야!", "선생님, 안녕하세요!", "나 배고파요!", "놀러 가자!"],
    answer: "선생님, 안녕하세요!", explanation: "수업을 시작할 때는 공손하게 '선생님, 안녕하세요!' 하고 바르게 인사해요."
  },
  {
    id: "g12_mc_02", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "다음 중 학교 교실에서 지켜야 할 바른 태도는 무엇일까요?",
    options: ["친구의 필통을 허락 없이 가져간다.", "선생님 말씀에 귀를 쫑긋 기울인다.", "교실 바닥에 침을 뱉는다.", "책상 위에 낙서를 마구 한다."],
    answer: "선생님 말씀에 귀를 쫑긋 기울인다.", explanation: "선생님과 친구의 말에 귀를 기울이고 경청하는 것이 바른 교실 태도예요."
  },
  {
    id: "g12_mc_03", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "친구와 사이좋게 어울려 놀기 위해 가장 필요한 마음가짐은 무엇일까요?",
    options: ["배려와 양보", "욕심과 고집", "질투와 시기", "무관심과 외면"],
    answer: "배려와 양보", explanation: "친구의 입장을 먼저 생각하는 배려와 양보가 있으면 다툼 없이 사이좋게 놀 수 있어요."
  },
  {
    id: "g12_mc_04", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "학교에서 재미있는 책을 빌려 읽을 수 있는 특별한 교실은 어디일까요?",
    options: ["도서관", "과학실", "급식실", "체육관"],
    answer: "도서관", explanation: "도서관에는 다양한 그림책과 이야기책이 가득하여 마음껏 빌려볼 수 있어요."
  },
  {
    id: "g12_mc_05", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "체육관이나 운동장에서 체육 수업을 할 때 입기에 가장 알맞은 옷차림은?",
    options: ["활동하기 편한 운동복과 운동화", "두껍고 무거운 패딩 코트", "굽이 뾰족하고 높은 구두", "물에 젖은 수영복"],
    answer: "활동하기 편한 운동복과 운동화", explanation: "운동을 할 때는 몸을 자유롭게 움직이고 넘어지지 않도록 운동복과 운동화를 신어요."
  },
  {
    id: "g12_mc_06", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "친구의 생일에 축하하는 마음을 전할 때 건네기에 가장 알맞은 말은?",
    options: ["생일 축하해, 앞으로도 친하게 지내자!", "너만 선물 받아서 심술나!", "생일 별거 아니네!", "내 생일이 더 좋아!"],
    answer: "생일 축하해, 앞으로도 친하게 지내자!", explanation: "친구의 기쁜 날에는 진심을 담아 따뜻하게 축하해 주는 것이 좋아요."
  },
  {
    id: "g12_mc_07", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "급식 시간에 밥을 먹을 때 올바른 식사 예절은 무엇일까요?",
    options: ["음식을 입에 물고 큰 소리로 떠든다.", "골고루 먹고 식사 후 식판을 바르게 정리한다.", "싫어하는 반찬을 바닥에 몰래 버린다.", "친구의 반찬을 포크로 뺏어 먹는다."],
    answer: "골고루 먹고 식사 후 식판을 바르게 정리한다.", explanation: "음식을 골고루 감사한 마음으로 먹고, 다 먹은 식판은 퇴식구에 깨끗하게 반납해요."
  },
  {
    id: "g12_mc_08", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "학교 화장실을 이용할 때 지켜야 할 바른 모습이 아닌 것은?",
    options: ["노크를 똑똑 하고 들어간다.", "사용한 휴지는 휴지통이나 변기에 바르게 버린다.", "손을 깨끗이 비누로 씻는다.", "변기 뚜껑 위에 신발을 신고 올라선다."],
    answer: "변기 뚜껑 위에 신발을 신고 올라선다.", explanation: "변기 위에 신발을 신고 올라가면 미끄러져 크게 다칠 위험이 있어요."
  },
  {
    id: "g12_mc_09", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "우리 학교의 교장 선생님이 주로 근무하시는 방의 이름은 무엇일까요?",
    options: ["교장실", "음악실", "창고", "수위실"],
    answer: "교장실", explanation: "교장 선생님께서는 학교 전체를 보살피며 교장실에서 업무를 보십니다."
  },
  {
    id: "g12_mc_10", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "선생님께서 질문하셨을 때 내 생각을 발표하는 바른 방법은?",
    options: ["선생님 말씀이 끝나기 전에 소리 지른다.", "조용히 손을 들고 지목받으면 일어나서 또박또박 말한다.", "부끄러워서 책상 밑으로 숨는다.", "짝꿍에게 대신 말하라고 시킨다."],
    answer: "조용히 손을 들고 지목받으면 일어나서 또박또박 말한다.", explanation: "손을 들어 차례를 얻은 뒤 다른 친구들이 잘 들을 수 있게 바른 자세로 말해요."
  },
  {
    id: "g12_mc_11", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "봄을 알리는 대표적인 노란색 봄꽃은 무엇일까요?",
    options: ["개나리", "국화", "해바라기", "코스모스"],
    answer: "개나리", explanation: "개나리는 따뜻한 봄이 오면 가장 먼저 가지마다 노란 꽃망울을 터뜨려요."
  },
  {
    id: "g12_mc_12", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "더운 여름철에 체온을 식히고 땀띠를 예방하기 위한 생활 모습은?",
    options: ["에어컨과 선풍기 바람을 적절히 쐬고 자주 씻는다.", "뜨거운 난로 옆에 바짝 붙어 있는다.", "두꺼운 털부츠를 하루 종일 신고 있는다.", "물을 전혀 마시지 않고 참는다."],
    answer: "에어컨과 선풍기 바람을 적절히 쐬고 자주 씻는다.", explanation: "여름철에는 시원한 물로 몸을 씻고 물을 자주 마셔 수분을 보충해요."
  },
  {
    id: "g12_mc_13", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "가을의 대표적인 우리나라 전통 명절로, 송편을 빚어 먹는 날은?",
    options: ["추석", "설날", "단오", "어린이날"],
    answer: "추석", explanation: "추석(한가위)에는 햅쌀로 맛있는 송편을 빚고 보름달을 보며 소원을 빌어요."
  },
  {
    id: "g12_mc_14", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "추운 겨울철에 얼음 위에서 즐길 수 있는 전통 민속놀이는 무엇일까요?",
    options: ["썰매 타기와 팽이치기", "수영하기", "모래성 쌓기", "매미 잡기"],
    answer: "썰매 타기와 팽이치기", explanation: "겨울철 얼음판 위에서 나무 썰매를 타거나 팽이채로 팽이를 치며 놀았어요."
  },
  {
    id: "g12_mc_15", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "더운 여름에 강이나 바다에서 시원하게 할 수 있는 물놀이는?",
    options: ["수영", "스키 타기", "눈싸움", "연날리기"],
    answer: "수영", explanation: "여름에는 수영장이나 계곡, 바닷가에서 물놀이와 수영을 하며 더위를 이겨내요."
  },
  {
    id: "g12_mc_16", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "우리 동네에서 아픈 환자를 진찰하고 약을 처방해 주시는 의사 선생님이 계신 곳은?",
    options: ["병원", "세탁소", "꽃집", "문구점"],
    answer: "병원", explanation: "몸이 아플 때는 병원이나 의원에 가서 의사 선생님의 진료를 받아요."
  },
  {
    id: "g12_mc_17", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "공책, 연필, 지우개 같은 학용품을 살 수 있는 동네 가게는 어디일까요?",
    options: ["문구점", "정육점", "미용실", "약국"],
    answer: "문구점", explanation: "문구점에서는 공부할 때 필요한 공책, 필기구, 미술 도구 등을 판매해요."
  },
  {
    id: "g12_mc_18", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "동네 미용실에서 머리카락을 예쁘고 단정하게 다듬어 주시는 분은?",
    options: ["미용사", "요리사", "기관사", "조종사"],
    answer: "미용사", explanation: "미용사 선생님은 가위와 빗으로 사람들의 머리를 멋지게 손질해 주십니다."
  },
  {
    id: "g12_mc_19", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리 마을의 여러 가지 민원 서류를 떼거나 도움을 요청하는 공공기관은?",
    options: ["주민센터(행정복지센터)", "놀이공원", "노래방", "영화관"],
    answer: "주민센터(행정복지센터)", explanation: "주민센터(행정복지센터)는 마을 사람들의 편의와 복지를 위해 일하는 공공기관이에요."
  },
  {
    id: "g12_mc_20", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "빵과 케이크를 향긋하고 맛있게 구워 파는 동네 가게는 어디일까요?",
    options: ["제과점(빵집)", "철물점", "카센터", "주유소"],
    answer: "제과점(빵집)", explanation: "제과점(베이커리)에서는 제빵사 아저씨가 맛있는 빵과 과자를 구워내요."
  },
  {
    id: "g12_mc_21", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "길을 건널 때 안전하게 건널 수 있도록 도로에 하얀 줄로 표시된 곳은?",
    options: ["횡단보도", "고속도로", "골목길", "주차장"],
    answer: "횡단보도", explanation: "길을 건널 때는 반드시 보행자 신호등이 있는 횡단보도로 건너야 안전해요."
  },
  {
    id: "g12_mc_22", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "횡단보도를 안전하게 건너는 3단계 원칙으로 가장 알맞은 것은?",
    options: ["멈춘다 ➔ 살핀다 ➔ 건넌다", "뛴다 ➔ 눕는다 ➔ 구른다", "춤춘다 ➔ 노래한다 ➔ 소리친다", "눈을 감는다 ➔ 달린다 ➔ 멈춘다"],
    answer: "멈춘다 ➔ 살핀다 ➔ 건넌다", explanation: "신호등 앞에서 일단 멈추고, 좌우를 살핀 뒤, 차가 멈춘 것을 보고 손을 들고 건너요."
  },
  {
    id: "g12_mc_23", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "위급한 화재나 응급 환자가 생겼을 때 119에 전화하면 출동하는 차는?",
    options: ["소방차와 구급차", "포클레인", "덤프트럭", "트랙터"],
    answer: "소방차와 구급차", explanation: "불이 나면 소방차가, 아픈 사람이 있으면 구급차가 신속히 출동해요."
  },
  {
    id: "g12_mc_24", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "지진이 나서 교실 땅이 흔들릴 때 가장 먼저 취해야 할 안전 행동은?",
    options: ["책상 밑으로 들어가 책상 다리를 꼭 잡는다.", "창문을 열고 밖으로 뛰어내린다.", "선생님을 밀치고 복도로 달린다.", "칠판 뒤로 숨는다."],
    answer: "책상 밑으로 들어가 책상 다리를 꼭 잡는다.", explanation: "지진이 나면 천장에서 물건이 떨어질 수 있으니 튼튼한 책상 밑으로 들어가 머리를 보호해요."
  },
  {
    id: "g12_mc_25", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "비가 올 때 우산을 쓰며 길을 걸을 때 안전한 방법은 무엇일까요?",
    options: ["우산을 앞으로 기울여 앞이 안 보이게 걷는다.", "우산을 바르게 들어 앞을 잘 보면서 걷는다.", "우산으로 칼싸움을 하며 장난친다.", "우산을 던지며 논다."],
    answer: "우산을 바르게 들어 앞을 잘 보면서 걷는다.", explanation: "우산으로 앞을 가리면 다가오는 차나 자전거를 보지 못해 위험해요."
  },
  {
    id: "g12_mc_26", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "자전거, 킥보드, 인라인스케이트를 탈 때 머리를 보호하기 위해 꼭 써야 하는 것은?",
    options: ["안전모(헬멧)", "밀짚모자", "선글라스", "수영모자"],
    answer: "안전모(헬멧)", explanation: "넘어졌을 때 머리를 다치지 않으려면 단단한 안전 헬멧과 무릎 보호대를 착용해야 해요."
  },
  {
    id: "g12_mc_27", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "집에서 혼자 있을 때 낯선 사람이 벨을 누르면 어떻게 해야 할까요?",
    options: ["문을 덜컥 열어준다.", "문을 열지 않고 부모님께 먼저 전화해 알린다.", "비밀번호를 알려준다.", "들어오라고 초대한다."],
    answer: "문을 열지 않고 부모님께 먼저 전화해 알린다.", explanation: "모르는 사람에게 절대 문을 열어주지 말고 부모님께 즉시 연락해야 안전해요."
  },
  {
    id: "g12_mc_28", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "다음 중 가족 구성원들이 서로 돕는 아름다운 모습으로 가장 알맞은 것은?",
    options: ["내가 쓴 장난감은 동생에게 치우라고 시킨다.", "식사 준비와 설거지를 부모님과 함께 거든다.", "엄마 아빠가 말씀하실 때 귀를 막는다.", "방을 어지르고 청소를 안 한다."],
    answer: "식사 준비와 설거지를 부모님과 함께 거든다.", explanation: "집안일을 함께 돕고 분담할 때 가족 모두가 행복해져요."
  },
  {
    id: "g12_mc_29", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "엘리베이터를 탈 때 안전하게 이용하는 방법은 무엇일까요?",
    options: ["문이 닫힐 때 억지로 손이나 발을 끼워 넣는다.", "엘리베이터 안에서 쿵쿵 높이 뛴다.", "차례대로 타고 버튼을 장난으로 마구 누르지 않는다.", "비상벨을 장난으로 누른다."],
    answer: "차례대로 타고 버튼을 장난으로 마구 누르지 않는다.", explanation: "엘리베이터에서 뛰거나 문에 손을 대면 고장이 나거나 갇힐 수 있어요."
  },
  {
    id: "g12_mc_30", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "위험한 도둑을 신고하거나 길을 잃었을 때 경찰관서에 거는 긴급 전화번호는?",
    options: ["112", "114", "119", "131"],
    answer: "112", explanation: "경찰관서 범죄 신고 전화는 112, 화재 및 응급 구조 전화는 119예요."
  },

  // --- 1~2학년군 단답형 (20문항) ---
  {
    id: "g12_sa_01", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "학교에서 몸이 아프거나 다쳤을 때 약을 바르고 쉬러 가는 방의 이름은 무엇일까요?",
    options: [], answer: "보건실", explanation: "보건실에는 보건 선생님이 계셔서 아픈 학생을 돌봐주십니다."
  },
  {
    id: "g12_sa_02", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "선생님과 학생들이 한 교실에 모여 수업을 듣는 학급 단위 공간을 무엇이라고 부를까요?",
    options: [], answer: "교실", explanation: "교실은 친구들과 함께 공부하고 생활하는 가장 중심적인 공간이에요."
  },
  {
    id: "g12_sa_03", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "수업 시간 사이에 화장실에 다녀오거나 쉴 수 있는 10분 정도의 짧은 시간을 무엇이라고 할까요?",
    options: [], answer: "쉬는 시간", explanation: "수업과 수업 사이에 주어지는 쉼의 시간을 쉬는 시간이라고 해요."
  },
  {
    id: "g12_sa_04", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "학교 운동장에서 체육을 하거나 흙장난을 하며 쉴 수 있는 넓은 야외 공간은?",
    options: [], answer: "운동장", explanation: "운동장은 달리기나 축구 등 신체활동을 할 수 있는 학교의 넓은 터예요."
  },
  {
    id: "g12_sa_05", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "학교에서 친구들과 다 함께 맛있게 점심 식사를 하는 건물의 이름은 무엇일까요?",
    options: [], answer: "급식실", explanation: "급식실(식당)에서는 영양사님과 조리사님이 정성스레 만든 음식을 먹어요."
  },
  {
    id: "g12_sa_06", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "날씨가 춥고 눈이 펑펑 내리며 얼음이 어는 계절의 이름은 무엇일까요?",
    options: [], answer: "겨울", explanation: "겨울은 일 년 중 가장 기온이 낮고 추운 계절이에요."
  },
  {
    id: "g12_sa_07", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "가을에 초록색 나뭇잎이 노랗고 붉게 물드는 아름다운 자연 현상을 무엇이라고 할까요?",
    options: [], answer: "단풍", explanation: "가을이 되면 기온이 떨어지면서 잎의 엽록소가 파괴되어 단풍이 들어요."
  },
  {
    id: "g12_sa_08", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "여름철 더위를 식히기 위해 손에 쥐고 흔들어 바람을 일으키는 전통 도구는?",
    options: [], answer: "부채", explanation: "부채는 옛날부터 선풍기가 없던 시절 손으로 바람을 내던 고마운 도구예요."
  },
  {
    id: "g12_sa_09", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "하늘에서 비가 내릴 때 비를 맞지 않도록 머리 위로 펼쳐 쓰는 물건은?",
    options: [], answer: "우산", explanation: "비가 올 때는 우산이나 우비를 착용하여 옷이 젖지 않게 보호해요."
  },
  {
    id: "g12_sa_10", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "새해 첫날(음력 1월 1일)에 떡국을 먹고 어른들께 세배를 드리는 명절의 이름은?",
    options: [], answer: "설날", explanation: "설날은 새해를 축하하며 떡국을 먹고 한 살 나이를 더 먹는 대표적인 명절이에요."
  },
  {
    id: "g12_sa_11", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "마을에 불이 났을 때 긴급하게 출동하여 불을 꺼주는 공공기관은 어디일까요?",
    options: [], answer: "소방서", explanation: "소방서는 화재 진압과 긴급 구조 활동을 담당하는 안전 기관이에요."
  },
  {
    id: "g12_sa_12", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "범죄를 예방하고 순찰을 돌며 마을의 치안을 지켜주시는 고마운 분들은 누구일까요?",
    options: [], answer: "경찰관", explanation: "경찰관님들은 순찰차를 타고 마을 곳곳의 안전을 지켜주십니다."
  },
  {
    id: "g12_sa_13", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "마을 골목길의 쓰레기를 청소하여 동네를 항상 깨끗하게 만들어 주시는 직업은?",
    options: [], answer: "환경미화원", explanation: "환경미화원분들은 쾌적한 마을 환경을 위해 묵묵히 청소해 주십니다."
  },
  {
    id: "g12_sa_14", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "몸이 아플 때 진료를 받고 의사 선생님의 처방전을 가져가 약을 사는 곳은?",
    options: [], answer: "약국", explanation: "약국에서 약사 선생님께 올바른 복약 지도를 받고 약을 구매해요."
  },
  {
    id: "g12_sa_15", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "마을 주민들이 책을 마음껏 읽고 빌릴 수 있도록 지어진 동네 시설은?",
    options: [], answer: "도서관", explanation: "도서관은 지식과 교양을 쌓을 수 있는 마을의 대표적인 문화 공간이에요."
  },
  {
    id: "g12_sa_16", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "차도에서 길을 건널 때 건널 수 있는 시기를 색깔로 알려주는 기구는?",
    options: [], answer: "신호등", explanation: "신호등의 초록불과 빨간불은 길을 건널 때 반드시 지켜야 할 약속이에요."
  },
  {
    id: "g12_sa_17", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "자동차를 탈 때 몸이 튕겨 나가지 않도록 몸에 두르는 안전 띠의 이름은?",
    options: [], answer: "안전띠", explanation: "안전띠(안전벨트)는 교통사고 충격으로부터 우리 몸을 보호해 주는 생명띠예요."
  },
  {
    id: "g12_sa_18", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "자전거를 탈 때 머리를 부딪치더라도 안전하게 지켜주는 머리 보호 장구는?",
    options: [], answer: "헬멧", explanation: "안전모(헬멧)는 머리를 보호하기 위해 반드시 착용해야 하는 필수 보호구예요."
  },
  {
    id: "g12_sa_19", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "불이 나거나 다친 사람이 있을 때 소방서로 전화하는 긴급 번호 세 자리는?",
    options: [], answer: "119", explanation: "119는 소방청 긴급 출동 번호이며, 장난전화는 절대 하면 안 돼요."
  },
  {
    id: "g12_sa_20", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "집안에 불이 났을 때 연기를 마시지 않기 위해 코와 입을 막는 물건은?",
    options: [], answer: "젖은 수건", explanation: "물에 적신 젖은 수건이나 옷으로 코와 입을 막아야 뜨거운 유독가스를 걸러낼 수 있어요."
  },

  // --- 1~2학년군 서술형 (10문항) ---
  {
    id: "g12_desc_01", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "복도나 계단에서 뛰지 않고 오른쪽으로 조용히 걸어야 하는 까닭을 쓰세요.",
    options: [], answer: "친구들과 부딪혀 다치는 사고를 막고, 수업 중인 교실에 방해가 되지 않기 위해서입니다.",
    grading_keywords: ["부딪", "다치", "사고", "안전", "방해", "조용"],
    explanation: "복도에서 뛰면 마주 오는 친구와 충돌해 큰 상처를 입을 수 있으니 안전하게 우측통행해야 해요."
  },
  {
    id: "g12_desc_02", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "수업 시간에 발표할 때 다른 친구들의 말을 끝까지 잘 들어주어야 하는 까닭을 적어보세요.",
    options: [], answer: "친구의 생각을 존중하고, 이야기를 잘 들어야 나도 더 많은 것을 배울 수 있기 때문입니다.",
    grading_keywords: ["친구", "생각", "존중", "배려", "경청", "예절"],
    explanation: "발표하는 친구를 존중하는 경청 태도는 교실에서 서로를 배려하는 가장 기본적인 예절이에요."
  },
  {
    id: "g12_desc_03", grade_group: "1~2학년군", unit_name: "학교와 나", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "친구와 장난감을 가지고 놀 때 장난감을 혼자만 독차지하면 안 되는 까닭을 쓰세요.",
    options: [], answer: "친구의 마음이 상하고 함께 즐겁게 놀 수 없으므로, 차례를 지키며 양보해야 하기 때문입니다.",
    grading_keywords: ["친구", "양보", "차례", "함께", "즐겁", "다툼"],
    explanation: "함께 노는 장난감은 서로 양보하고 규칙을 지켜야 친구와 다투지 않고 우정을 쌓을 수 있어요."
  },
  {
    id: "g12_desc_04", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "여름철에 물놀이를 갈 때 준비운동을 꼭 먼저 해야 하는 까닭은 무엇일까요?",
    options: [], answer: "차가운 물에 갑자기 들어가면 근육에 쥐가 나거나 심장이 놀라 위험할 수 있기 때문입니다.",
    grading_keywords: ["심장", "근육", "쥐", "놀라", "위험", "사고", "안전"],
    explanation: "준비운동을 통해 몸을 따뜻하게 풀어주어야 물속에서 다리에 쥐가 나는 사고를 예방할 수 있어요."
  },
  {
    id: "g12_desc_05", grade_group: "1~2학년군", unit_name: "계절과 우리 생활", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "겨울철에 눈이 꽁꽁 얼어붙은 빙판길을 걸을 때 주머니에 손을 넣지 않아야 하는 까닭을 적어보세요.",
    options: [], answer: "미끄러져 넘어질 때 손으로 바닥을 짚지 못해 머리나 얼굴을 크게 다칠 수 있기 때문입니다.",
    grading_keywords: ["넘어", "미끄", "손", "얼굴", "머리", "다치", "보호"],
    explanation: "주머니에 손을 넣고 걷다 넘어지면 얼굴이나 머리를 크게 다칠 수 있으므로 장갑을 끼고 손을 빼고 걸어야 해요."
  },
  {
    id: "g12_desc_06", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "우리 동네를 위해 일하시는 소방관이나 환경미화원분들께 감사한 마음을 가져야 하는 까닭을 쓰세요.",
    options: [], answer: "우리가 안전하고 깨끗한 환경에서 건강하고 행복하게 살아갈 수 있도록 도와주시기 때문입니다.",
    grading_keywords: ["안전", "깨끗", "건강", "도움", "감사", "마을"],
    explanation: "우리 마을의 여러 일꾼들 덕분에 매일 안전하고 깨끗한 일상을 누릴 수 있으므로 감사해야 해요."
  },
  {
    id: "g12_desc_07", grade_group: "1~2학년군", unit_name: "우리 마을과 사람들", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "놀이터나 공원 같은 마을의 공공장소를 이용할 때 쓰레기를 함부로 버리면 안 되는 까닭은?",
    options: [], answer: "모두가 함께 사용하는 공간이 더러워지고 다른 사람들에게 불쾌감을 주기 때문입니다.",
    grading_keywords: ["모두", "함께", "공공", "더럽", "냄새", "배려"],
    explanation: "공공장소는 나 혼자만의 공간이 아니라 모두의 장소이므로 깨끗이 아껴 써야 해요."
  },
  {
    id: "g12_desc_08", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "초록불이 켜진 횡단보도를 건널 때도 바로 뛰어나가지 않고 좌우를 살펴야 하는 까닭을 쓰세요.",
    options: [], answer: "멈추지 못하고 달려오는 자동차나 오토바이가 있을 수 있어 차가 멈췄는지 확인해야 하기 때문입니다.",
    grading_keywords: ["자동차", "차", "오토바이", "멈추", "사고", "안전", "위험"],
    explanation: "신호등이 바뀌었더라도 멈추지 못한 차가 있을 수 있으니 반드시 차량 멈춤을 확인하고 건너야 해요."
  },
  {
    id: "g12_desc_09", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "자동차를 탈 때 짧은 거리라도 안전띠를 꼭 매야 하는 까닭은 무엇일까요?",
    options: [], answer: "갑작스러운 급정거나 교통사고가 났을 때 몸이 튕겨 나가지 않도록 생명을 보호하기 위해서입니다.",
    grading_keywords: ["사고", "급정거", "충격", "보호", "생명", "다치"],
    explanation: "안전띠는 사고 충격으로부터 우리 몸을 지켜주는 가장 소중한 생명줄이에요."
  },
  {
    id: "g12_desc_10", grade_group: "1~2학년군", unit_name: "가족과 안전", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "화재가 발생했을 때 엘리베이터를 타지 않고 계단으로 대피해야 하는 까닭을 적어보세요.",
    options: [], answer: "정전으로 엘리베이터가 멈춰 갇힐 수 있고, 연기가 통로를 타고 올라와 질식할 수 있기 때문입니다.",
    grading_keywords: ["정전", "멈추", "갇히", "연기", "질식", "위험"],
    explanation: "화재 시 전기가 끊기면 승강기 안에 갇혀 유독가스에 질식할 수 있으므로 계단으로 대피해야 해요."
  },


  // ============================================================================
  // [2] 초등학교 3~4학년군 (총 90문항: OX 30, 객관식 30, 단답형 20, 서술형 10)
  // ============================================================================
  // --- 3~4학년군 OX 퀴즈 (30문항) ---
  {
    id: "g34_ox_01", grade_group: "3~4학년군", unit_name: "우리가 사는 곳", question_type: "ox", difficulty: "하", base_score: 1,
    question: "같은 장소라도 사람들의 경험과 추억에 따라 느끼는 장소감은 서로 다를 수 있다.",
    options: [], answer: "O", explanation: "맞습니다. 같은 공원이라도 즐거웠던 사람과 다쳤던 사람의 감정은 다를 수 있어요."
  },
  {
    id: "g34_ox_02", grade_group: "3~4학년군", unit_name: "우리가 사는 곳", question_type: "ox", difficulty: "하", base_score: 1,
    question: "병원, 소방서, 공원 등은 우리 고장 사람들의 생활을 편리하고 안전하게 해주는 주요 시설이다.",
    options: [], answer: "O", explanation: "맞습니다. 주민들의 건강, 안전, 여가를 위한 필수 공공시설들입니다."
  },
  {
    id: "g34_ox_03", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "ox", difficulty: "하", base_score: 1,
    question: "지도의 방위표에서 화살표가 가리키는 쪽은 언제나 '남쪽'이다.",
    options: [], answer: "X", explanation: "틀립니다. 방위표의 뾰족한 화살표는 항상 '북쪽(North)'을 가리킵니다."
  },
  {
    id: "g34_ox_04", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "ox", difficulty: "중", base_score: 3,
    question: "지도에서 실제 땅의 크기를 줄여서 나타낸 비율을 '등고선'이라고 부른다.",
    options: [], answer: "X", explanation: "틀립니다. 실제 거리를 줄여서 나타낸 비율은 '축척'이고, 등고선은 높낮이를 나타냅니다."
  },
  {
    id: "g34_ox_05", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "ox", difficulty: "하", base_score: 1,
    question: "지도에 복잡한 건물이나 도로를 간단한 기호로 나타내고, 그 뜻을 설명해 둔 표를 '범례'라고 한다.",
    options: [], answer: "O", explanation: "맞습니다. 기호가 무엇을 뜻하는지 설명해 놓은 안내 상자를 '범례'라고 합니다."
  },
  {
    id: "g34_ox_06", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "ox", difficulty: "하", base_score: 1,
    question: "탑, 불상, 궁궐처럼 손으로 만질 수 있고 눈으로 볼 수 있는 문화유산을 '유형문화유산'이라고 한다.",
    options: [], answer: "O", explanation: "맞습니다. 형태가 있는 건축물이나 공예품 등은 유형문화유산입니다."
  },
  {
    id: "g34_ox_07", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "ox", difficulty: "하", base_score: 1,
    question: "판소리, 탈춤, 줄타기 등은 형태가 없어서 문화유산으로 인정받지 못한다.",
    options: [], answer: "X", explanation: "틀립니다. 형태는 없지만 대대로 이어온 예술과 기술은 소중한 '무형문화유산'입니다."
  },
  {
    id: "g34_ox_08", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "ox", difficulty: "하", base_score: 1,
    question: "문화유산에 내 이름을 낙서하여 흔적을 남기는 것은 문화유산을 사랑하는 올바른 방법이다.",
    options: [], answer: "X", explanation: "절대 안 됩니다! 문화유산에 낙서를 하거나 훼손하면 법적인 처벌을 받습니다."
  },
  {
    id: "g34_ox_09", grade_group: "3~4학년군", unit_name: "일상에서 만나는 과거", question_type: "ox", difficulty: "하", base_score: 1,
    question: "옛날 사람들이 사용하던 맷돌, 가마, 호롱불 등은 당시 사람들의 생활상을 알려주는 역사 증거이다.",
    options: [], answer: "O", explanation: "맞습니다. 조상들의 유물과 도구는 과거의 생활을 복원하는 중요한 증거가 됩니다."
  },
  {
    id: "g34_ox_10", grade_group: "3~4학년군", unit_name: "일상에서 만나는 과거", question_type: "ox", difficulty: "하", base_score: 1,
    question: "오래된 사진이나 신문 기사는 과거의 모습을 추론하는 데 아무런 도움이 되지 않는다.",
    options: [], answer: "X", explanation: "틀립니다. 옛 사진과 기록물은 과거 고장의 풍경과 역사를 생생히 보여줍니다."
  },
  {
    id: "g34_ox_11", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "ox", difficulty: "하", base_score: 1,
    question: "오늘날 우리 사회에는 결혼하지 않는 1인 가구, 반려동물 가족 등 다양한 가족 형태가 존재한다.",
    options: [], answer: "O", explanation: "맞습니다. 사회가 변화하면서 가족의 형태도 매우 다양해지고 있습니다."
  },
  {
    id: "g34_ox_12", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "ox", difficulty: "하", base_score: 1,
    question: "다른 나라에서 온 다문화 가정 친구의 문화나 피부색을 차별하거나 놀려서는 안 된다.",
    options: [], answer: "O", explanation: "맞습니다. 문화적 다양성을 존중하고 서로 배려하는 세계시민의 태도가 필요합니다."
  },
  {
    id: "g34_ox_13", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "ox", difficulty: "중", base_score: 3,
    question: "아이를 적게 낳는 현상을 '고령화', 노인 인구가 늘어나는 현상을 '저출산'이라고 부른다.",
    options: [], answer: "X", explanation: "틀립니다. 아이를 적게 낳는 것이 '저출산', 노인 인구가 많아지는 것이 '고령화'입니다."
  },
  {
    id: "g34_ox_14", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "옛날에는 말을 타거나 나룻배를 타고 이동했지만, 오늘날에는 고속열차와 비행기로 빠르게 이동한다.",
    options: [], answer: "O", explanation: "맞습니다. 교통수단이 눈부시게 발달하여 생활공간이 전 세계로 넓어졌습니다."
  },
  {
    id: "g34_ox_15", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "옛날에는 연기나 불빛으로 위급한 소식을 알리는 '봉수'라는 통신 수단을 사용했다.",
    options: [], answer: "O", explanation: "맞습니다. 산봉우리의 봉수대에서 낮에는 연기, 밤에는 횃불을 피워 국경의 소식을 알렸습니다."
  },
  {
    id: "g34_ox_16", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "스마트폰과 인터넷의 발달로 먼 거리에 있는 사람과도 실시간으로 얼굴을 보며 대화할 수 있다.",
    options: [], answer: "O", explanation: "맞습니다. 통신기술의 발달로 시공간의 한계를 넘어 소통이 가능해졌습니다."
  },
  {
    id: "g34_ox_17", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "ox", difficulty: "하", base_score: 1,
    question: "인간의 욕망은 무한하지만, 이를 채워줄 돈과 자원의 양은 한정되어 있는 현상을 '자원의 희소성'이라 한다.",
    options: [], answer: "O", explanation: "맞습니다. 자원의 희소성 때문에 우리는 비용과 편익을 따져 합리적 선택을 해야 합니다."
  },
  {
    id: "g34_ox_18", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "ox", difficulty: "하", base_score: 1,
    question: "필요한 물건을 만드는 활동은 '소비'이고, 물건을 돈을 주고 사서 쓰는 활동은 '생산'이다.",
    options: [], answer: "X", explanation: "반대입니다! 물건을 만드는 것이 '생산', 물건을 사서 쓰는 것이 '소비'입니다."
  },
  {
    id: "g34_ox_19", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "ox", difficulty: "하", base_score: 1,
    question: "바닷가 지역의 생선과 내륙 지방의 사과는 서로 교류하여 나누어 먹을 수 있다.",
    options: [], answer: "O", explanation: "맞습니다. 각 지역의 자연환경에 따라 생산물이 다르므로 지역 간 활발한 교류가 일어납니다."
  },
  {
    id: "g34_ox_20", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "ox", difficulty: "하", base_score: 1,
    question: "과소비나 충동구매는 나의 소중한 용돈을 낭비하게 만드는 비합리적인 소비 행동이다.",
    options: [], answer: "O", explanation: "맞습니다. 구매 전 꼭 필요한 물건인지 계획을 세우는 습관이 필요합니다."
  },
  {
    id: "g34_ox_21", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "ox", difficulty: "하", base_score: 1,
    question: "민주주의의 꽃인 학급 회장 선거에서는 한 사람이 10표씩 몰아서 투표할 수 있다.",
    options: [], answer: "X", explanation: "틀립니다. 누구나 공평하게 1인 1표를 행사하는 평등 선거 원칙이 지켜져야 합니다."
  },
  {
    id: "g34_ox_22", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "ox", difficulty: "중", base_score: 3,
    question: "학급 회의에서 다수결로 결정했더라도 적은 표를 얻은 소수의 의견을 무시해서는 안 된다.",
    options: [], answer: "O", explanation: "맞습니다. 다수결을 따르되 소수 의견의 권리와 가치도 끝까지 존중해야 합니다."
  },
  {
    id: "g34_ox_23", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "ox", difficulty: "하", base_score: 1,
    question: "지역 주민들이 스스로 마을의 문제를 해결하고 의논하는 제도를 '주민 자치'라고 한다.",
    options: [], answer: "O", explanation: "맞습니다. 살기 좋은 마을을 주민 스스로 만들어가는 풀뿌리 민주주의입니다."
  },
  {
    id: "g34_ox_24", grade_group: "3~4학년군", unit_name: "지역문제를 해결하고 지역을 알리는 노력", question_type: "ox", difficulty: "하", base_score: 1,
    question: "마을의 쓰레기 배출 문제나 주차 갈등은 주민들이 대화와 타협을 통해 민주적으로 해결할 수 있다.",
    options: [], answer: "O", explanation: "맞습니다. 주민 회의와 협의를 통해 규칙을 정하여 갈등을 슬기롭게 해결합니다."
  },
  {
    id: "g34_ox_25", grade_group: "3~4학년군", unit_name: "지역문제를 해결하고 지역을 알리는 노력", question_type: "ox", difficulty: "하", base_score: 1,
    question: "고장의 특산물이나 전통 축제를 널리 알리면 지역 경제 활성화에 도움이 된다.",
    options: [], answer: "O", explanation: "맞습니다. 관광객이 찾아오고 특산물이 많이 팔려 지역 발전에 큰 힘이 됩니다."
  },
  {
    id: "g34_ox_26", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "높은 산과 깊은 골짜기가 많은 산지촌에서는 주로 배를 타고 물고기를 잡으며 생활한다.",
    options: [], answer: "X", explanation: "틀립니다. 물고기를 잡는 곳은 어촌이고, 산지촌에서는 버섯 채취나 목축업 등을 합니다."
  },
  {
    id: "g34_ox_27", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "도시는 인구와 건물이 밀집해 있고 상업과 서비스업 등 다양한 산업이 발달한 곳이다.",
    options: [], answer: "O", explanation: "맞습니다. 도시는 교통이 편리하고 많은 사람이 모여 사는 중심지입니다."
  },
  {
    id: "g34_ox_28", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "ox", difficulty: "중", base_score: 3,
    question: "도시에는 사람이 많이 몰려 살기 때문에 교통 체증, 주택 부족, 쓰레기 오염 등의 문제가 생긴다.",
    options: [], answer: "O", explanation: "맞습니다. 과도한 인구 집중에 따른 대표적인 도시 문제들입니다."
  },
  {
    id: "g34_ox_29", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "자연환경을 무분별하게 개발하여 파괴해도 인간에게는 아무런 피해가 돌아오지 않는다.",
    options: [], answer: "X", explanation: "틀립니다. 무분별한 개발은 홍수, 산사태, 기후변화 등 큰 재앙으로 인간에게 되돌아옵니다."
  },
  {
    id: "g34_ox_30", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "환경을 보전하면서도 필요한 만큼만 슬기롭게 이용하는 '지속가능한 개발'이 중요하다.",
    options: [], answer: "O", explanation: "맞습니다. 미래 세대를 위해 환경을 지키며 개발하는 지혜가 필요합니다."
  },

  // --- 3~4학년군 객관식 (30문항) ---
  {
    id: "g34_mc_01", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "지도에서 산이나 언덕의 높낮이를 나타내기 위해 같은 높이의 지점을 연결한 곡선은 무엇일까요?",
    options: ["등고선", "방위선", "경도선", "축척선"],
    answer: "등고선", explanation: "등고선은 해수면을 기준으로 같은 높이의 점들을 이은 선으로 땅의 기복을 보여줍니다."
  },
  {
    id: "g34_mc_02", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "지도에서 1cm가 실제 거리 50,000cm(500m)를 나타낸다면, 이것을 뜻하는 지도의 요소는?",
    options: ["축척", "방위표", "기호", "범례"],
    answer: "축척", explanation: "실제 거리를 줄여서 지도에 표시한 축소 비율을 '축척'이라고 합니다."
  },
  {
    id: "g34_mc_03", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "방위표에서 북쪽을 마주 보고 섰을 때, 나의 '오른쪽'이 가리키는 방향은 어디일까요?",
    options: ["동쪽", "서쪽", "남쪽", "북동쪽"],
    answer: "동쪽", explanation: "북쪽을 바라보면 오른쪽이 동쪽, 왼쪽이 서쪽, 등 뒤가 남쪽이 됩니다."
  },
  {
    id: "g34_mc_04", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "조선 시대 정조 임금이 세운 계획도시이자 유네스코 세계유산에 등재된 건축 문화유산은?",
    options: ["수원 화성", "경복궁 근정전", "불국사 다보탑", "첨성대"],
    answer: "수원 화성", explanation: "수원 화성은 정조의 효심과 실학자 정약용의 거중기 기술이 담긴 자랑스러운 문화유산입니다."
  },
  {
    id: "g34_mc_05", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "우리 고장의 문화재와 역사 자료를 안전하게 전시하고 보관하는 장소는 어디일까요?",
    options: ["박물관", "백화점", "야구장", "주유소"],
    answer: "박물관", explanation: "박물관은 선조들의 유적과 유물을 발굴하고 보존하여 시민들에게 전시하는 곳입니다."
  },
  {
    id: "g34_mc_06", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "다음 중 '무형문화유산'에 속하는 것만을 바르게 짝지은 것은 무엇일까요?",
    options: ["탈춤, 판소리, 씨름", "석가탑, 다보탑, 첨성대", "팔만대장경, 직지심체요절", "남한산성, 수원화성"],
    answer: "탈춤, 판소리, 씨름", explanation: "탈춤, 판소리, 전통 무예(씨름, 택견) 등은 형체는 없으나 인간의 기능과 예술에 담긴 무형유산입니다."
  },
  {
    id: "g34_mc_07", grade_group: "3~4학년군", unit_name: "일상에서 만나는 과거", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "옛날에 밤에 방 안을 밝히기 위해 기름을 붓고 심지에 불을 붙여 켜던 도구는?",
    options: ["호롱불", "손전등", "형광등", "스마트폰"],
    answer: "호롱불", explanation: "전기가 들어오기 전 조상들은 호롱불이나 촛불을 켜서 어두운 밤을 밝혔습니다."
  },
  {
    id: "g34_mc_08", grade_group: "3~4학년군", unit_name: "일상에서 만나는 과거", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "옛날 곡식을 갈아 가루로 만들던 무거운 두 짝의 돌로 된 전통 생활 도구는 무엇일까요?",
    options: ["맷돌", "절구", "가마", "키"],
    answer: "맷돌", explanation: "위짝과 아래짝으로 구성된 맷돌에 콩이나 곡식을 넣고 손잡이(어처구니)를 돌려 갈았습니다."
  },
  {
    id: "g34_mc_09", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "서로 다른 문화적 배경을 가진 사람들이 모여 살며 다양한 문화가 공존하는 사회를 무엇이라 할까요?",
    options: ["다문화 사회", "단일민족 사회", "원시 사회", "봉건 사회"],
    answer: "다문화 사회", explanation: "세계화와 이주의 증가로 다양한 언어, 관습, 종교가 어우러지는 다문화 사회가 되었습니다."
  },
  {
    id: "g34_mc_10", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리 사회의 심각한 인구 문제 중 하나로, 전체 인구에서 65세 이상 노인의 비율이 높아지는 현상은?",
    options: ["고령화", "저출산", "산업화", "도시화"],
    answer: "고령화", explanation: "의학 발달과 기대 수명 연장으로 노인 인구 비율이 증가하는 현상을 고령화라고 합니다."
  },
  {
    id: "g34_mc_11", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "음력 5월 5일 명절로, 창포물에 머리를 감고 그네뛰기와 씨름을 즐겼던 우리나라 명절은?",
    options: ["단오", "추석", "한식", "동지"],
    answer: "단오", explanation: "단오는 양기가 가장 왕성한 날로, 창포물 머리감기와 수리취떡 먹기 등의 세시 풍속이 있습니다."
  },
  {
    id: "g34_mc_12", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "옛날에 먼 곳에 소식을 전하기 위해 편지를 전달하던 주요 통신 수단이 아닌 것은?",
    options: ["스마트폰 메신저", "파발(말과 사람)", "봉수(연기와 불)", "비둘기"],
    answer: "스마트폰 메신저", explanation: "스마트폰 메신저는 현대의 통신 수단이며, 옛날에는 파발, 봉수, 전령 등을 이용했습니다."
  },
  {
    id: "g34_mc_13", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "소비자가 물건을 구매할 때 가격, 품질, 필요성 등을 꼼꼼하게 따져 만족을 극대화하는 선택은?",
    options: ["합리적 선택", "충동구매", "과소비", "모방 소비"],
    answer: "합리적 선택", explanation: "자신의 예산 한도 내에서 가장 큰 만족과 효용을 얻는 선택을 합리적 선택이라고 합니다."
  },
  {
    id: "g34_mc_14", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "생산자와 소비자가 만나 상품과 서비스를 자유롭게 사고파는 장소를 무엇이라고 부를까요?",
    options: ["시장", "우체국", "경찰서", "학교"],
    answer: "시장", explanation: "전통시장, 대형마트, 인터넷 쇼핑몰 등 재화와 서비스의 거래가 이루어지는 곳을 시장이라고 합니다."
  },
  {
    id: "g34_mc_15", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "제주도의 감귤과 대관령의 황태처럼 특정 지역에서 특별히 많이 나거나 품질이 우수한 생산물은?",
    options: ["지역 특산물", "공산품", "수입품", "재활용품"],
    answer: "지역 특산물", explanation: "그 지역의 독특한 기후나 지형적 특성 덕분에 생산되는 대표적인 산물을 특산물이라고 합니다."
  },
  {
    id: "g34_mc_16", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "학급 회의나 선거에서 여러 의견 중 가장 많은 표를 얻은 의견을 따르는 민주적 의사결정 원리는?",
    options: ["다수결의 원칙", "만장일치의 원칙", "연장자 우선 원칙", "추첨의 원칙"],
    answer: "다수결의 원칙", explanation: "모든 사람의 합의가 어려울 때 다수의 찬성을 따르되 소수 의견도 존중하는 원리입니다."
  },
  {
    id: "g34_mc_17", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "우리 고장의 주민들이 직접 투표로 뽑는 지방자치단체 대표는 누구일까요?",
    options: ["시장·군수·구청장", "국무총리", "대법원장", "경찰청장"],
    answer: "시장·군수·구청장", explanation: "주민들은 선거를 통해 시장, 군수, 구청장 및 지방의회 의원을 직접 선출합니다."
  },
  {
    id: "g34_mc_18", grade_group: "3~4학년군", unit_name: "지역문제를 해결하고 지역을 알리는 노력", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "마을 주민들이 겪는 주차난이나 층간소음 같은 갈등 문제를 해결하는 가장 바람직한 방법은?",
    options: ["주민 회의를 열어 대화와 타협으로 규칙을 정한다.", "다툼을 벌이며 경찰에 무조건 고소한다.", "남의 일이라며 신경 쓰지 않는다.", "이사 가라고 욕설을 퍼붓는다."],
    answer: "주민 회의를 열어 대화와 타협으로 규칙을 정한다.", explanation: "주민 자치의 핵심은 주민들이 함께 모여 대화와 타협으로 합리적인 규칙을 만드는 것입니다."
  },
  {
    id: "g34_mc_19", grade_group: "3~4학년군", unit_name: "지역문제를 해결하고 지역을 알리는 노력", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "보령 머드 축제, 안동 탈춤 축제처럼 고장의 특색을 살려 관광객을 유치하는 행사는?",
    options: ["지역 축제", "전국체전", "국회 청문회", "대통령 선거"],
    answer: "지역 축제", explanation: "지역 축제는 고장의 자연환경이나 전통문화를 관광 상품화하여 널리 알리는 대표적인 노력입니다."
  },
  {
    id: "g34_mc_20", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "넓은 들판(평야)을 중심으로 벼농사나 밭농사를 주로 지으며 살아가는 마을은?",
    options: ["농촌", "어촌", "산지촌", "광산촌"],
    answer: "농촌", explanation: "농촌은 흙과 물이 풍부한 평야 지역에서 농업을 주업으로 하는 촌락입니다."
  },
  {
    id: "g34_mc_21", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "바닷가에 위치하여 고기잡이나 양식업, 염전 등을 주업으로 하는 마을의 이름은?",
    options: ["어촌", "농촌", "공업단지", "신도시"],
    answer: "어촌", explanation: "어촌은 바다를 무대로 수산물을 채취하고 양식하는 사람들의 생활 터전입니다."
  },
  {
    id: "g34_mc_22", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "도시와 촌락의 관계를 가장 바르게 설명한 것은 무엇일까요?",
    options: ["도시와 촌락은 서로 필요한 것을 주고받는 상호의존 관계이다.", "도시는 촌락보다 항상 우월하므로 촌락을 무시해도 된다.", "도시와 촌락은 서로 아무런 교류가 없다.", "촌락은 도시에 일방적으로 피해만 준다."],
    answer: "도시와 촌락은 서로 필요한 것을 주고받는 상호의존 관계이다.", explanation: "촌락은 신선한 농수산물을 제공하고, 도시는 공산품과 의료·문화 서비스를 제공하며 돕습니다."
  },
  {
    id: "g34_mc_23", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "도시의 심각한 교통 혼잡 문제를 줄이기 위해 시민들이 실천할 수 있는 가장 좋은 방법은?",
    options: ["대중교통(지하철, 버스) 이용하기", "나홀로 자가용 매일 타기", "불법 주차하기", "도로에 쓰레기 버리기"],
    answer: "대중교통(지하철, 버스) 이용하기", explanation: "대중교통 이용과 카풀은 도로의 차량 수를 줄이고 환경 오염도 줄여줍니다."
  },
  {
    id: "g34_mc_24", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리나라의 수도이자 최대 인구가 모여 살며 정치·경제의 중심지인 특별시는?",
    options: ["서울특별시", "부산광역시", "제주특별자치도", "세종특별자치시"],
    answer: "서울특별시", explanation: "서울특별시는 대한민국의 수도로서 한강을 중심으로 번영한 거대 도시입니다."
  },
  {
    id: "g34_mc_25", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "과거 신라 시대의 수도였으며 첨성대, 불국사, 석굴암 등 수많은 문화유산이 보존된 고장은?",
    options: ["경상북도 경주시", "전북특별자치도 전주시", "강원특별자치도 강릉시", "충청남도 공주시"],
    answer: "경상북도 경주시", explanation: "경주는 천년 신라의 찬란한 불교 문화유산이 도시 전체에 가득한 지붕 없는 박물관입니다."
  },
  {
    id: "g34_mc_26", grade_group: "3~4학년군", unit_name: "우리가 사는 곳", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "우리 고장의 모습을 하늘 높은 곳에서 비행기나 인공위성으로 촬영한 사진 지도는?",
    options: ["위성사진(항공사진)", "백지도", "노선도", "그림지도"],
    answer: "위성사진(항공사진)", explanation: "위성사진과 항공지도는 실제 고장의 지형과 건물 모습을 그대로 생생히 보여줍니다."
  },
  {
    id: "g34_mc_27", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "소비자가 물건을 살 때 물건값의 일부를 기부하거나 공정무역 제품을 사는 착한 소비는?",
    options: ["윤리적 소비", "충동구매", "과시 소비", "사재기"],
    answer: "윤리적 소비", explanation: "환경과 이웃, 노동자의 인권을 생각하며 가치 있게 물건을 사는 행위를 윤리적 소비라 합니다."
  },
  {
    id: "g34_mc_28", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "추운 겨울철에 여러 가정에서 온 가족과 친척이 모여 겨우내 먹을 김치를 대량으로 담그는 풍습은?",
    options: ["김장", "단오", "성묘", "모내기"],
    answer: "김장", explanation: "김장은 유네스코 인류무형문화유산으로도 등재된 조상들의 슬기로운 나눔과 저장 문화입니다."
  },
  {
    id: "g34_mc_29", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "국민이 나라의 주인으로서 나라의 중요한 일에 직접 참여하고 결정하는 정치 제도는?",
    options: ["민주주의", "군주제", "독재정치", "신분제"],
    answer: "민주주의", explanation: "민주주의(Democracy)는 모든 권력이 국민으로부터 나오는 국민 주권의 정치 형태입니다."
  },
  {
    id: "g34_mc_30", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리나라 지도에서 바다 쪽으로 튀어나와 3면이 바다로 둘러싸인 땅을 무엇이라 할까요?",
    options: ["반도", "섬", "호수", "사막"],
    answer: "반도", explanation: "한반도는 삼면이 동해, 서해, 남해로 둘러싸인 대표적인 반도 지형입니다."
  },

  // --- 3~4학년군 단답형 (20문항) ---
  {
    id: "g34_sa_01", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "지도에서 동서남북의 4가지 방향을 알려주는 지도 요소의 이름은 무엇일까요?",
    options: [], answer: "방위표", explanation: "방위표는 지도에서 방위를 판별하는 가장 기본적인 도구입니다."
  },
  {
    id: "g34_sa_02", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "실제 땅의 거리를 일정한 비율로 줄여서 지도에 나타낸 비율을 무엇이라고 할까요?",
    options: [], answer: "축척", explanation: "축척은 큰 공간을 작은 지도로 축소할 때 사용하는 축소 비율입니다."
  },
  {
    id: "g34_sa_03", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "지도에 나타난 여러 가지 기호들의 뜻을 알아보기 쉽게 풀어서 설명해 놓은 표는?",
    options: [], answer: "범례", explanation: "범례를 읽으면 지도에 쓰인 다양한 기호의 의미를 명확히 알 수 있습니다."
  },
  {
    id: "g34_sa_04", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "형태는 없으나 조상들의 기술이나 예술적 재능이 담긴 문화재(예: 판소리, 탈춤)를 무엇이라 할까요?",
    options: [], answer: "무형문화유산", explanation: "형체가 없는 전통 공연, 공예 기술 등은 무형문화유산에 해당합니다."
  },
  {
    id: "g34_sa_05", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "궁궐, 탑, 석굴암처럼 일정한 형태가 있는 역사적 건축물이나 미술품을 뜻하는 문화유산은?",
    options: [], answer: "유형문화유산", explanation: "물질적인 형태를 가진 문화재를 유형문화유산이라고 부릅니다."
  },
  {
    id: "g34_sa_06", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "사람들의 욕망에 비해 사용할 수 있는 자원이나 돈의 양이 부족한 상태를 뜻하는 단어는?",
    options: [], answer: "희소성", explanation: "자원의 희소성은 모든 경제 문제의 근본적인 원인이 됩니다."
  },
  {
    id: "g34_sa_07", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "생활에 필요한 재화나 서비스를 새롭게 만들어내는 경제 활동을 무엇이라고 할까요?",
    options: [], answer: "생산", explanation: "물건을 만들거나 서비스를 제공하는 활동을 생산이라고 합니다."
  },
  {
    id: "g34_sa_08", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "생산된 재화나 서비스를 돈을 지불하고 사서 생활에 사용하는 활동은?",
    options: [], answer: "소비", explanation: "필요한 물건을 구매하고 사용하는 활동을 소비라고 합니다."
  },
  {
    id: "g34_sa_09", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "회의에서 의견이 갈릴 때 더 많은 사람이 찬성한 쪽을 따르는 민주적 원리는?",
    options: [], answer: "다수결의 원칙", explanation: "다수결의 원칙은 효율적인 의사결정 방식이나 소수의견 배려가 필수입니다."
  },
  {
    id: "g34_sa_10", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "우리 마을이나 학교에서 대표자를 직접 뽑는 민주주의의 가장 중요한 행사는?",
    options: [], answer: "선거", explanation: "선거는 주권자인 시민이 대표를 선출하는 신성한 민주적 절차입니다."
  },
  {
    id: "g34_sa_11", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "바다에서 물고기를 잡거나 조개, 김, 미역 등을 기르며 살아가는 바닷가 마을은?",
    options: [], answer: "어촌", explanation: "어촌은 해양 수산업을 중심으로 생활공간이 형성된 촌락입니다."
  },
  {
    id: "g34_sa_12", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "인구와 건물이 빽빽하게 모여 있고 회사, 상점, 병원 등이 밀집된 중심 공간은?",
    options: [], answer: "도시", explanation: "도시는 2차, 3차 산업과 인구가 밀집된 현대 사회의 중심 생활공간입니다."
  },
  {
    id: "g34_sa_13", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "옛날 산꼭대기에서 낮에는 연기, 밤에는 횃불을 피워 위급한 국경 상황을 알리던 통신 수단은?",
    options: [], answer: "봉수", explanation: "봉수제도는 전국 5대 간선망을 통해 군사 소식을 전달하던 전통 통신망입니다."
  },
  {
    id: "g34_sa_14", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "아기 출산율이 점점 낮아져서 태어나는 아기의 수가 급격히 줄어드는 현상을 무엇이라 할까요?",
    options: [], answer: "저출산", explanation: "저출산은 장차 청년 인구 감소와 사회 활력 저하를 초래하는 심각한 문제입니다."
  },
  {
    id: "g34_sa_15", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "전체 사회 인구 중 65세 이상의 할머니, 할아버지 인구 비율이 높아지는 사회 현상은?",
    options: [], answer: "고령화", explanation: "노인 인구의 비중이 커지는 사회를 고령화 사회라고 부릅니다."
  },
  {
    id: "g34_sa_16", grade_group: "3~4학년군", unit_name: "지역문제를 해결하고 지역을 알리는 노력", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "나주 배, 횡성 한우처럼 그 지역에서 특별히 생산되어 품질을 인정받는 산물을 무엇이라 할까요?",
    options: [], answer: "특산물", explanation: "지역 특산물은 해당 고장의 지리적 환경과 주민의 정성이 빚어낸 명품입니다."
  },
  {
    id: "g34_sa_17", grade_group: "3~4학년군", unit_name: "우리가 사는 곳", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "비행기나 인공위성에서 고장의 지형과 건물 모습을 그대로 촬영한 실제 사진 지도는?",
    options: [], answer: "위성사진", explanation: "위성사진이나 항공사진은 지형지물의 생생한 실물을 파악하는 데 유용합니다."
  },
  {
    id: "g34_sa_18", grade_group: "3~4학년군", unit_name: "일상에서 만나는 과거", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "옛날 사람들이 곡식에서 쭉정이(껍질)와 먼지를 바람에 날려 가려내던 부채 모양의 전통 도구는?",
    options: [], answer: "키", explanation: "키질을 통해 무거운 알곡은 안으로 모으고 가벼운 티끌은 바람에 날려 보냈습니다."
  },
  {
    id: "g34_sa_19", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "음력 8월 15일로 햅쌀로 빚은 송편을 먹고 보름달을 보며 조상께 감사하는 명절은?",
    options: [], answer: "추석", explanation: "한가위 추석은 오곡백과가 풍성한 우리나라 최대의 가을 명절입니다."
  },
  {
    id: "g34_sa_20", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "자연환경을 보호하면서 동시에 경제적 이익도 창출하는 미래 지향적 발전 방식을 무엇이라 할까요?",
    options: [], answer: "지속가능한 발전", explanation: "환경과 경제가 균형을 이루어 미래 세대에게 물려줄 발전을 지속가능한 발전이라 합니다."
  },

  // --- 3~4학년군 서술형 (10문항) ---
  {
    id: "g34_desc_01", grade_group: "3~4학년군", unit_name: "민주주의와 자치", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "학급 회의에서 다수결로 결정을 내릴 때, 표를 적게 얻은 '소수의 의견'도 존중해야 하는 까닭을 서술하세요.",
    options: [], answer: "다수의 의견이 항상 옳은 것은 아니며, 소수의 의견 속에도 훌륭한 생각과 권리가 담겨 있기 때문입니다.",
    grading_keywords: ["소수", "옳", "틀릴", "권리", "존중", "배려", "의견"],
    explanation: "민주주의에서는 다수결로 결정하더라도 소외된 소수의 인권과 합리적인 의견을 존중해야 진정한 합의가 됩니다."
  },
  {
    id: "g34_desc_02", grade_group: "3~4학년군", unit_name: "우리 지역의 문화유산", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "조상들이 남겨주신 우리 고장의 소중한 문화유산을 잘 보존하고 지켜야 하는 까닭을 적어보세요.",
    options: [], answer: "문화유산에는 조상의 역사와 슬기가 담겨 있으며, 한 번 훼손되면 다시 원래대로 되돌릴 수 없기 때문입니다.",
    grading_keywords: ["조상", "역사", "지혜", "보존", "훼손", "되돌", "후손", "자랑"],
    explanation: "문화유산은 한 번 파괴되면 영원히 복구할 수 없는 인류의 자산이므로 정성껏 아끼고 보존해야 합니다."
  },
  {
    id: "g34_desc_03", grade_group: "3~4학년군", unit_name: "경제활동과 지역 간 교류", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "물건을 살 때 충동구매를 피하고 '합리적인 선택'을 해야 하는 까닭을 '자원의 희소성'과 연관 지어 쓰세요.",
    options: [], answer: "우리가 가진 돈과 자원은 한정되어 있으므로, 꼭 필요한 것인지 따져 가장 큰 만족을 얻어야 하기 때문입니다.",
    grading_keywords: ["자원", "한정", "희소", "돈", "필요", "만족", "효용"],
    explanation: "소득과 자원이 한정되어 있으므로 비용 대비 만족도가 높은 선택을 계획적으로 실천해야 합니다."
  },
  {
    id: "g34_desc_04", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "도시와 촌락이 서로 경쟁하거나 다투지 않고 '상호의존 관계'로 협력해야 하는 까닭을 설명하세요.",
    options: [], answer: "촌락은 도시 사람들을 위한 신선한 농수산물을 생산하고, 도시는 촌락에 공산품과 생활 편의 시설을 제공하기 때문입니다.",
    grading_keywords: ["농수산물", "식량", "공산품", "병원", "도움", "서로", "돕"],
    explanation: "도시와 촌락은 각자 생산하는 가치가 다르므로 서로 부족한 점을 채워주는 공존의 파트너입니다."
  },
  {
    id: "g34_desc_05", grade_group: "3~4학년군", unit_name: "지도로 만나는 우리 지역", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "지도에 복잡한 건물의 실제 모습을 그대로 그리지 않고 간단한 '기호'와 '범례'를 사용하는 까닭을 쓰세요.",
    options: [], answer: "작은 지도 안에 고장의 수많은 정보와 건물을 한눈에 알아보기 쉽게 간결하게 나타내기 위해서입니다.",
    grading_keywords: ["한눈", "알아보", "간단", "축소", "좁", "복잡"],
    explanation: "복잡한 실제 땅의 정보를 작은 종이에 누구나 쉽게 읽을 수 있도록 약속된 상징(기호)을 사용합니다."
  },
  {
    id: "g34_desc_06", grade_group: "3~4학년군", unit_name: "사회 변화와 다양한 문화", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "우리 사회에 다문화 가정이 늘어남에 따라 우리가 가져야 할 바람직한 태도를 서술하세요.",
    options: [], answer: "피부색이나 국적으로 편견을 갖지 않고, 다른 나라의 전통과 문화를 존중하며 함께 어울려야 합니다.",
    grading_keywords: ["편견", "차별", "존중", "배려", "이해", "어울"],
    explanation: "문화의 우열을 따지지 않고 다름을 인정하며 포용하는 열린 다문화 감수성이 필요합니다."
  },
  {
    id: "g34_desc_07", grade_group: "3~4학년군", unit_name: "지역문제를 해결하고 지역을 알리는 노력", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "고장의 주차난이나 쓰레기 문제를 해결할 때 주민들의 적극적인 '참여'가 중요한 까닭을 쓰세요.",
    options: [], answer: "고장의 문제는 주민들의 생활과 직접 관련되어 있으며, 주민들이 함께 협의해야 실천 가능한 해결책이 나오기 때문입니다.",
    grading_keywords: ["주민", "생활", "직접", "협의", "실천", "해결", "관심"],
    explanation: "행정 기관의 힘만으로는 한계가 있으므로 주민 스스로 주인의식을 갖고 참여할 때 문제가 근본적으로 해결됩니다."
  },
  {
    id: "g34_desc_08", grade_group: "3~4학년군", unit_name: "옛날과 오늘날의 생활 모습", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "교통수단(비행기, 고속철도)의 발달이 사람들의 생활공간을 어떻게 변화시켰는지 설명하세요.",
    options: [], answer: "이동 시간이 획기적으로 줄어들어 하루 만에 전국이나 세계 여러 나라를 오갈 수 있게 생활공간이 넓어졌습니다.",
    grading_keywords: ["시간", "단축", "빠르", "넓", "확대", "하루", "이동"],
    explanation: "시공간의 압축으로 지역 간 교류가 활발해지고 활동 반경이 전 지구적 스케일로 확장되었습니다."
  },
  {
    id: "g34_desc_09", grade_group: "3~4학년군", unit_name: "다양한 환경과 삶의 모습", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "도시의 심각한 대기오염과 열섬 현상을 줄이기 위해 도시 환경을 어떻게 가꾸어야 하는지 서술하세요.",
    options: [], answer: "도시 숲과 공원을 조성하고 옥상 녹화를 늘리며, 친환경 대중교통과 자전거 도로를 확충해야 합니다.",
    grading_keywords: ["공원", "숲", "나무", "녹지", "대중교통", "자전거", "친환경"],
    explanation: "도시에 녹지 공간을 넓히고 화석연료 배출을 줄여 쾌적한 생태도시로 전환해야 합니다."
  },
  {
    id: "g34_desc_10", grade_group: "3~4학년군", unit_name: "일상에서 만나는 과거", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "가정이나 박물관에 있는 오래된 물건(일기, 생활 도구)이 역사적으로 귀중한 가치를 지니는 까닭을 쓰세요.",
    options: [], answer: "책에 나오지 않는 옛날 사람들의 실제 생각과 일상생활의 변화를 생생하게 증명해 주는 자료이기 때문입니다.",
    grading_keywords: ["증거", "자료", "생활", "모습", "증명", "알려"],
    explanation: "손때 묻은 유물과 기록은 그 시대를 살았던 사람들의 생생한 삶의 궤적을 복원하는 중요한 1차 사료입니다."
  },


  // ============================================================================
  // [3] 초등학교 5~6학년군 (총 90문항: OX 30, 객관식 30, 단답형 20, 서술형 10)
  // ============================================================================
  // --- 5~6학년군 OX 퀴즈 (30문항) ---
  {
    id: "g56_ox_01", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "ox", difficulty: "하", base_score: 1,
    question: "한 나라의 주권이 미치는 국토의 범위는 영토(땅), 영해(바다), 영공(하늘)을 모두 포함한다.",
    options: [], answer: "O", explanation: "맞습니다. 국가의 주권이 온전히 미치는 공간적 범위는 영토, 영해, 영공입니다."
  },
  {
    id: "g56_ox_02", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "ox", difficulty: "하", base_score: 1,
    question: "독도는 역사적, 지리적, 국제법적으로 명백한 대한민국의 고유한 영토이다.",
    options: [], answer: "O", explanation: "맞습니다. 삼국사기, 신증동국여지승람 등 수많은 역사 기록이 독도가 우리 땅임을 증명합니다."
  },
  {
    id: "g56_ox_03", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "ox", difficulty: "중", base_score: 3,
    question: "우리나라 한반도는 서쪽에 높은 산맥이 있고 동쪽으로 갈수록 평야가 펼쳐진 서고동저 지형이다.",
    options: [], answer: "X", explanation: "틀립니다. 동쪽이 높고 서쪽이 낮은 '동고서저' 지형입니다."
  },
  {
    id: "g56_ox_04", grade_group: "5~6학년군", unit_name: "우리나라 지리 탐구", question_type: "ox", difficulty: "하", base_score: 1,
    question: "우리나라 여름철 날씨는 북태평양 기단의 영향으로 덥고 습한(고온 다습) 특징이 나타난다.",
    options: [], answer: "O", explanation: "맞습니다. 고온 다습한 기후로 인해 여름철 장마와 무더위가 찾아옵니다."
  },
  {
    id: "g56_ox_05", grade_group: "5~6학년군", unit_name: "우리나라 지리 탐구", question_type: "ox", difficulty: "중", base_score: 3,
    question: "우리나라 인구의 절반 이상이 서울, 인천, 경기 등 수도권에 집중되어 국토 불균형 문제가 발생한다.",
    options: [], answer: "O", explanation: "맞습니다. 수도권 과밀화와 지방 소멸 위기는 국가 균형 발전을 통해 해결해야 할 큰 과제입니다."
  },
  {
    id: "g56_ox_06", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "ox", difficulty: "하", base_score: 1,
    question: "헌법은 모든 법률의 으뜸이자 최고 법률이며, 국민의 기본적인 인권을 보장한다.",
    options: [], answer: "O", explanation: "맞습니다. 헌법에 어긋나는 법률은 효력을 잃으며, 헌법은 인권 보장의 최후 보루입니다."
  },
  {
    id: "g56_ox_07", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "ox", difficulty: "하", base_score: 1,
    question: "인권은 성별, 종교, 인종, 신분에 관계없이 인간이라면 누구나 태어나면서부터 갖는 고유한 권리이다.",
    options: [], answer: "O", explanation: "맞습니다. 천부인권 사상에 따라 누구도 타인의 인권을 침해할 수 없습니다."
  },
  {
    id: "g56_ox_08", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "ox", difficulty: "중", base_score: 3,
    question: "국민의 기본권은 국가의 안전보장이나 질서유지를 위해서라도 법률로 절대 제한할 수 없다.",
    options: [], answer: "X", explanation: "틀립니다. 국가 안전이나 공공복리를 위해 필요한 경우 헌법에 따라 법률로 제한할 수 있으나 본질은 침해할 수 없습니다."
  },
  {
    id: "g56_ox_09", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "단군왕검이 세운 우리 민족 최초의 국가는 고조선이다.",
    options: [], answer: "O", explanation: "맞습니다. 고조선은 널리 인간을 이롭게 한다는 홍익인간의 이념으로 건국되었습니다."
  },
  {
    id: "g56_ox_10", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "신라의 불국사와 석굴암은 당시 찬란했던 신라의 불교 예술과 과학 기술을 보여준다.",
    options: [], answer: "O", explanation: "맞습니다. 유네스코 세계유산으로 등록된 신라의 위대한 문화유산입니다."
  },
  {
    id: "g56_ox_11", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "ox", difficulty: "중", base_score: 3,
    question: "고구려를 계승하여 만주와 연해주 일대를 호령했던 '해동성국'이라 불린 나라는 백제이다.",
    options: [], answer: "X", explanation: "틀립니다. 고구려를 계승해 동쪽의 번성한 나라로 불린 국가는 '발해'입니다."
  },
  {
    id: "g56_ox_12", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "조선 시대 세종대왕은 백성들이 문자를 쉽게 읽고 쓸 수 있도록 1443년에 훈민정음을 창제했다.",
    options: [], answer: "O", explanation: "맞습니다. 세종대왕의 애민정신이 담긴 한글은 과학적이고 독창적인 문자입니다."
  },
  {
    id: "g56_ox_13", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "ox", difficulty: "중", base_score: 3,
    question: "고려 시대의 예성강 하구 벽란도는 송나라뿐 아니라 아라비아 상인들까지 왕래하던 국제 무역항이었다.",
    options: [], answer: "O", explanation: "맞습니다. 벽란도를 통해 '코리아(Korea)'라는 이름이 전 세계에 널리 알려졌습니다."
  },
  {
    id: "g56_ox_14", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "ox", difficulty: "하", base_score: 1,
    question: "조선 후기에는 서민들의 경제력이 성장하면서 판소리, 탈춤, 한글 소설 등 서민 문화가 크게 발달했다.",
    options: [], answer: "O", explanation: "맞습니다. 양반 중심 문화에서 벗어나 서민들의 솔직한 감정을 담은 예술이 꽃피웠습니다."
  },
  {
    id: "g56_ox_15", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "1919년 3월 1일, 일제의 식민 지배에 맞서 전국 방방곡곡에서 태극기를 들고 만세 시위를 벌였다.",
    options: [], answer: "O", explanation: "맞습니다. 3·1 운동은 대한민국 임시정부 수립의 도화선이 된 위대한 평화적 민족 운동입니다."
  },
  {
    id: "g56_ox_16", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "ox", difficulty: "하", base_score: 1,
    question: "1945년 8월 15일 우리나라는 일제의 탄압에서 벗어나 광복을 맞이하였다.",
    options: [], answer: "O", explanation: "맞습니다. 독립투사들의 치열한 항일 투쟁과 연합군의 승리로 국권을 되찾았습니다."
  },
  {
    id: "g56_ox_17", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "ox", difficulty: "중", base_score: 3,
    question: "1950년 6월 25일 북한의 기습 남침으로 발발한 6·25 전쟁은 수많은 사상자와 이산가족을 낳았다.",
    options: [], answer: "O", explanation: "맞습니다. 민족 최대의 비극이었으며, 현재까지도 분단의 아픔이 이어지고 있습니다."
  },
  {
    id: "g56_ox_18", grade_group: "5~6학년군", unit_name: "평화 통일을 위한 노력, 민주화와 산업화", question_type: "ox", difficulty: "하", base_score: 1,
    question: "1960년 부정선거에 맞서 학생들이 중심이 되어 독재 정권을 무너뜨린 민주화 운동은 4·19 혁명이다.",
    options: [], answer: "O", explanation: "맞습니다. 4·19 혁명은 대한민국 헌법 전문에도 수록된 자랑스러운 민주주의 역사입니다."
  },
  {
    id: "g56_ox_19", grade_group: "5~6학년군", unit_name: "평화 통일을 위한 노력, 민주화와 산업화", question_type: "ox", difficulty: "중", base_score: 3,
    question: "우리나라는 광복 이후 최빈국에서 출발하여 초고속 경제 성장을 이루어 '한강의 기적'이라 불린다.",
    options: [], answer: "O", explanation: "맞습니다. 국민들의 근면과 땀방울로 세계적인 경제 강국으로 발돋움했습니다."
  },
  {
    id: "g56_ox_20", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "ox", difficulty: "하", base_score: 1,
    question: "국가 권력의 집중과 독재를 막기 위해 국회, 행정부, 법원으로 권력을 분립한 것을 '삼권분립'이라 한다.",
    options: [], answer: "O", explanation: "맞습니다. 입법, 행정, 사법부가 서로를 견제하고 균형을 이루어 국민의 자유를 보호합니다."
  },
  {
    id: "g56_ox_21", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "ox", difficulty: "하", base_score: 1,
    question: "민주주의 선거의 4대 원칙은 보통 선거, 평등 선거, 직접 선거, 비밀 선거이다.",
    options: [], answer: "O", explanation: "맞습니다. 누구나 일정한 나이에 1인 1표를 직접 행사하며, 투표 내용은 비밀입니다."
  },
  {
    id: "g56_ox_22", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "ox", difficulty: "중", base_score: 3,
    question: "법을 만들고 고치는 '입법' 권한을 가진 기관은 법원이고, 판결을 내리는 기관은 국회이다.",
    options: [], answer: "X", explanation: "반대입니다! 법을 만드는 곳은 '국회(입법부)', 법에 따라 판결하는 곳은 '법원(사법부)'입니다."
  },
  {
    id: "g56_ox_23", grade_group: "5~6학년군", unit_name: "지구, 대륙 그리고 국가들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "지구상에는 아시아, 유럽, 아프리카, 북아메리카, 남아메리카, 오세아니아의 6대륙이 있다.",
    options: [], answer: "O", explanation: "맞습니다. 지구의 육지는 크게 6대주(대륙)로 나뉩니다."
  },
  {
    id: "g56_ox_24", grade_group: "5~6학년군", unit_name: "지구, 대륙 그리고 국가들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "둥근 지구의 모습을 평면에 그대로 펼친 세계지도는 면적이나 거리에 왜곡이 전혀 없다.",
    options: [], answer: "X", explanation: "틀립니다. 둥근 공 모양을 평면 종이에 옮기면 극지방 쪽의 면적이나 형태가 왜곡될 수밖에 없습니다."
  },
  {
    id: "g56_ox_25", grade_group: "5~6학년군", unit_name: "세계의 자연환경", question_type: "ox", difficulty: "하", base_score: 1,
    question: "적도 주변의 열대 기후 지역은 연중 기온이 높고 비가 많이 내려 빽빽한 정글(밀림)을 이룬다.",
    options: [], answer: "O", explanation: "맞습니다. 아마존 등 열대 우림은 지구의 허파 역할을 하는 생태계의 보고입니다."
  },
  {
    id: "g56_ox_26", grade_group: "5~6학년군", unit_name: "세계의 자연환경", question_type: "ox", difficulty: "중", base_score: 3,
    question: "비가 거의 내리지 않는 건조 기후 사막 지역에서는 흙으로 두껍게 벽을 쌓은 흙벽돌집을 짓는다.",
    options: [], answer: "O", explanation: "맞습니다. 사막은 낮과 밤의 기온 차가 극심하므로 창문을 작게 내고 벽을 두껍게 만듭니다."
  },
  {
    id: "g56_ox_27", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "ox", difficulty: "하", base_score: 1,
    question: "국가 간에 필요한 물건과 자원을 사고파는 국제적인 거래 활동을 '무역'이라고 부른다.",
    options: [], answer: "O", explanation: "맞습니다. 각 나라가 잘 만드는 것에 특화하여 교역하면 서로에게 이익이 됩니다."
  },
  {
    id: "g56_ox_28", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "ox", difficulty: "중", base_score: 3,
    question: "기업은 오직 이윤만 추구하면 되며, 환경 보호나 사회적 책임(ESG)은 신경 쓸 필요가 없다.",
    options: [], answer: "X", explanation: "틀립니다. 현대의 성숙한 기업은 환경을 지키고 사회에 공헌하는 사회적 책임을 다해야 합니다."
  },
  {
    id: "g56_ox_29", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "국제연합(UN)은 전 세계의 평화를 유지하고 빈곤과 질병을 해결하기 위해 설립된 국제기구이다.",
    options: [], answer: "O", explanation: "맞습니다. UN은 세계 각국이 모여 지구촌 문제를 평화적으로 해결하는 중심 기구입니다."
  },
  {
    id: "g56_ox_30", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "ox", difficulty: "하", base_score: 1,
    question: "기후위기나 전염병 문제는 한 국가만의 문제가 아니라 전 지구촌이 연대하여 해결해야 할 공통 과제이다.",
    options: [], answer: "O", explanation: "맞습니다. 지구 환경과 평화는 국경이 없으므로 모든 세계시민이 협력해야 합니다."
  },

  // --- 5~6학년군 객관식 (30문항) ---
  {
    id: "g56_mc_01", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리나라 영토의 가장 끝에 위치한 4극(극동, 극서, 극남, 극북) 중 '극동(가장 동쪽)'에 위치한 섬은?",
    options: ["독도", "마라도", "백령도", "가거도"],
    answer: "독도", explanation: "우리나라 가장 동쪽 끝은 경상북도 울릉군 울릉읍 독도리입니다."
  },
  {
    id: "g56_mc_02", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "우리나라 남쪽 바다 끝에 위치한 우리나라 최남단 유인도는 어디일까요?",
    options: ["마라도", "울릉도", "거제도", "강화도"],
    answer: "마라도", explanation: "제주도 서귀포시 대정읍에 속한 마라도는 대한민국의 최남단 섬입니다."
  },
  {
    id: "g56_mc_03", grade_group: "5~6학년군", unit_name: "우리나라 지리 탐구", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "겨울철 시베리아 기단의 확장으로 삼일 동안 춥고 사일 동안 포근한 날씨가 반복되는 현상은?",
    options: ["삼한사온", "장마", "태풍", "열대야"],
    answer: "삼한사온", explanation: "삼한사온은 한반도 겨울철 기후의 대표적인 주기적 온도 변화 특성입니다."
  },
  {
    id: "g56_mc_04", grade_group: "5~6학년군", unit_name: "우리나라 지리 탐구", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리나라 수도권 집중 현상을 완화하고 국토의 균형 있는 발전을 위해 취한 정책으로 알맞은 것은?",
    options: ["세종특별자치시와 혁신도시 건설", "서울 시내에 공장 집중 증설", "지방 학교의 대규모 폐교", "수도권에 모든 대기업 몰아주기"],
    answer: "세종특별자치시와 혁신도시 건설", explanation: "정부 부처를 세종시로 이전하고 지방에 공공기관 혁신도시를 세워 균형 발전을 도모합니다."
  },
  {
    id: "g56_mc_05", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "법률이 헌법에 위반되는지 심판하고, 국가 권력에 의해 기본권을 침해당했을 때 구제해 주는 기관은?",
    options: ["헌법재판소", "경찰청", "공정거래위원회", "한국은행"],
    answer: "헌법재판소", explanation: "헌법재판소는 위헌법률심판, 헌법소원심판 등을 통해 헌법을 수호하고 기본권을 지킵니다."
  },
  {
    id: "g56_mc_06", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "헌법에 규정된 국민의 기본권 중 다른 사람에게 부당하게 차별받지 않을 권리는 무엇일까요?",
    options: ["평등권", "자유권", "사회권", "청구권"],
    answer: "평등권", explanation: "평등권은 성별, 종교, 사회적 신분에 의해 차별받지 않고 동등하게 대우받을 권리입니다."
  },
  {
    id: "g56_mc_07", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "청동기 시대의 지배자이자 족장의 무덤으로, 거대한 바위를 괸돌 위에 얹어 놓은 유적은?",
    options: ["고인돌", "석굴암", "무령왕릉", "첨성대"],
    answer: "고인돌", explanation: "고인돌은 청동기 시대 족장의 권력을 상징하는 대표적인 무덤 유적입니다."
  },
  {
    id: "g56_mc_08", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "고구려의 전성기를 이끌며 만주벌판을 정복하고 대제국을 건설한 정복 군주는 누구일까요?",
    options: ["광개토대왕", "근초고왕", "진흥왕", "온조왕"],
    answer: "광개토대왕", explanation: "광개토대왕은 만주와 요동을 아우르는 광활한 영토를 개척한 위대한 정복 군주입니다."
  },
  {
    id: "g56_mc_09", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "신라가 삼국을 통일하는 데 결정적인 역할을 한 화랑도의 지도자이자 명장은 누구일까요?",
    options: ["김유신", "계백", "을지문덕", "강감찬"],
    answer: "김유신", explanation: "김유신 장군은 태종 무열왕과 함께 삼국 통일의 대업을 완수한 신라의 최고 명장입니다."
  },
  {
    id: "g56_mc_10", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "고려를 건국하고 후삼국을 통일하였으며, 민생 안정과 훈요 10조를 남긴 왕은 누구일까요?",
    options: ["태조 왕건", "광종", "공민왕", "이성계"],
    answer: "태조 왕건", explanation: "태조 왕건은 호족을 포용하고 발해 유민을 받아들여 918년에 고려를 건국했습니다."
  },
  {
    id: "g56_mc_11", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "조선 시대 세종대왕 때 장영실 등이 참여하여 만든 세계 최초의 측우기는 무엇을 재는 기구일까요?",
    options: ["내린 비의 양(강우량)", "바람의 세기", "땅의 온도", "해의 고도"],
    answer: "내린 비의 양(강우량)", explanation: "측우기는 농업에 필수적인 강우량을 과학적으로 측정하기 위해 발명된 기상 관측 도구입니다."
  },
  {
    id: "g56_mc_12", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "임진왜란 당시 거북선을 만들고 한산도 대첩과 명량 해전에서 왜군을 물리친 구국의 영웅은?",
    options: ["이순신", "권율", "곽재우", "원균"],
    answer: "이순신", explanation: "이순신 장군은 세계 해전사에 빛나는 불패의 지략으로 나라의 제해권을 지켜냈습니다."
  },
  {
    id: "g56_mc_13", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "조선 후기 씨름, 서당 등의 그림을 통해 서민들의 일상생활을 생동감 있게 그린 풍속화가는?",
    options: ["김홍도", "안견", "정선", "신사임당"],
    answer: "김홍도", explanation: "단원 김홍도는 조선 후기 서민들의 해학과 노동을 따뜻한 필치로 담아낸 대표 화가입니다."
  },
  {
    id: "g56_mc_14", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "1919년 3·1 만세 운동 당시 아우내 장터에서 만세 시위를 주도하다 순국한 열사는?",
    options: ["유관순", "안중근", "윤봉길", "김구"],
    answer: "유관순", explanation: "유관순 열사는 어린 나이에도 굴하지 않고 대한독립만세를 외친 민족의 영웅입니다."
  },
  {
    id: "g56_mc_15", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "일제의 침략 원흉인 이토 히로부미를 1909년 하얼빈역에서 처단한 대한의군 참모중장은?",
    options: ["안중근", "이봉창", "윤봉길", "신돌석"],
    answer: "안중근", explanation: "안중근 의사는 동양 평화를 염원하며 조국 침략의 주범을 처단하고 순국하셨습니다."
  },
  {
    id: "g56_mc_16", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "상하이에서 수립되어 1945년 광복 때까지 독립운동의 중심 역할을 한 망명 정부의 명칭은?",
    options: ["대한민국 임시정부", "조선총독부", "대한제국", "한성정부"],
    answer: "대한민국 임시정부", explanation: "대한민국 임시정부는 3·1 운동의 정신을 이어받아 민주공화제 정부를 수립했습니다."
  },
  {
    id: "g56_mc_17", grade_group: "5~6학년군", unit_name: "평화 통일을 위한 노력, 민주화와 산업화", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "1980년 5월, 군부 독재에 맞서 광주 시민들이 민주주의를 외치며 희생된 민주화 운동은?",
    options: ["5·18 민주화운동", "3·15 부정선거", "4·19 혁명", "6·25 전쟁"],
    answer: "5·18 민주화운동", explanation: "5·18 민주화운동은 유네스코 세계기록유산에도 등재된 숭고한 민주화 항쟁입니다."
  },
  {
    id: "g56_mc_18", grade_group: "5~6학년군", unit_name: "평화 통일을 위한 노력, 민주화와 산업화", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "1987년 6월 항쟁의 결과로 국민들이 대통령을 직접 손으로 뽑을 수 있게 바뀐 제도는?",
    options: ["대통령 직선제", "간선제", "세습제", "추첨제"],
    answer: "대통령 직선제", explanation: "시민들의 피와 땀으로 국민이 직접 투표하는 대통령 직선제 개헌을 이뤄냈습니다."
  },
  {
    id: "g56_mc_19", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "국민이 선출한 대표인 국회의원들이 모여 법률을 제정하고 정부를 감시하는 헌법 기관은?",
    options: ["국회", "법원", "감사원", "검찰청"],
    answer: "국회", explanation: "국회는 국민의 뜻을 대변하여 법을 만드는 입법부의 최고 기관입니다."
  },
  {
    id: "g56_mc_20", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "대통령과 국무총리, 각부 장관이 모여 국가의 행정 사무를 집행하는 기관은?",
    options: ["행정부(정부)", "사법부", "입법부", "헌법재판소"],
    answer: "행정부(정부)", explanation: "행정부는 국회에서 만든 법을 바탕으로 국가 정책과 예산을 살림살이합니다."
  },
  {
    id: "g56_mc_21", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "선거에서 부자든 가난한 사람이든 상관없이 누구나 똑같이 1인 1표를 행사하는 원칙은?",
    options: ["평등 선거", "보통 선거", "직접 선거", "비밀 선거"],
    answer: "평등 선거", explanation: "평등 선거는 모든 유권자의 표의 가치가 동등하게 1표로 인정받는 원칙입니다."
  },
  {
    id: "g56_mc_22", grade_group: "5~6학년군", unit_name: "지구, 대륙 그리고 국가들", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "지구에서 가장 넓은 바다이며, 아시아와 아메리카 대륙 사이에 위치한 바다는?",
    options: ["태평양", "대서양", "인도양", "북극해"],
    answer: "태평양", explanation: "태평양은 지구 전체 해양 면적의 절반 가까이를 차지하는 가장 거대한 대양입니다."
  },
  {
    id: "g56_mc_23", grade_group: "5~6학년군", unit_name: "지구, 대륙 그리고 국가들", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "지구본에서 가로로 그어진 선으로, 적도를 0도로 하여 남북의 위치를 나타내는 선은?",
    options: ["위도", "경도", "본초자오선", "날짜변경선"],
    answer: "위도", explanation: "위도는 적도를 기준으로 북위와 남위로 나뉘며, 일사량과 기후에 결정적 영향을 줍니다."
  },
  {
    id: "g56_mc_24", grade_group: "5~6학년군", unit_name: "세계의 자연환경", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "북극해 주변의 툰드라 지대처럼 일 년 내내 얼음과 눈이 녹지 않는 추운 기후는?",
    options: ["한대 기후", "열대 기후", "온대 기후", "건조 기후"],
    answer: "한대 기후", explanation: "한대 기후는 최난월 기온도 10도 미만으로 매우 추워 나무가 자라지 못합니다."
  },
  {
    id: "g56_mc_25", grade_group: "5~6학년군", unit_name: "세계의 자연환경", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "비가 너무 많이 오는 열대 기후 지역에서 땅의 열기와 습기를 피하기 위해 짓는 가옥은?",
    options: ["고상 가옥 (기둥을 높이 올린 집)", "이글루 (얼음집)", "흙벽돌집", "이동식 텐트(게르)"],
    answer: "고상 가옥 (기둥을 높이 올린 집)", explanation: "기둥을 높이 세워 바닥을 띄운 고상 가옥은 뱀이나 해충, 습기와 침수를 막아줍니다."
  },
  {
    id: "g56_mc_26", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리나라가 다른 나라에 물건을 수출하고 대가로 받는 외국 돈을 원화로 바꿀 때 적용되는 교환 비율은?",
    options: ["환율", "이자율", "물가상승률", "세율"],
    answer: "환율", explanation: "환율은 자기 나라 돈과 다른 나라 돈의 교환 비율(가치)을 뜻합니다."
  },
  {
    id: "g56_mc_27", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "다음 중 가계와 기업의 경제적 역할을 가장 바르게 짝지은 것은?",
    options: ["가계는 소비의 주체, 기업은 생산의 주체", "가계는 세금 징수 주체, 기업은 법률 제정 주체", "가계는 수출 주체, 기업은 무소비 주체", "가계와 기업은 경제활동을 하지 않음"],
    answer: "가계는 소비의 주체, 기업은 생산의 주체", explanation: "가계는 노동을 제공하고 물품을 소비하며, 기업은 재화를 생산하고 일자리를 만듭니다."
  },
  {
    id: "g56_mc_28", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "multiple_choice", difficulty: "하", base_score: 1,
    question: "전쟁이나 재난으로 고통받는 세계 어린이를 구호하기 위해 설립된 UN 산하 국제기구는?",
    options: ["유니세프(UNICEF)", "국제통화기금(IMF)", "세계무역기구(WTO)", "국제축구연맹(FIFA)"],
    answer: "유니세프(UNICEF)", explanation: "유니세프는 전 세계 어린이들의 생존, 발달, 보호를 위해 활동하는 아동 구호 기구입니다."
  },
  {
    id: "g56_mc_29", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "인류가 미래 세대를 위해 2030년까지 달성하기로 약속한 17개 글로벌 목표의 명칭은?",
    options: ["지속가능발전목표(SDGs)", "베르사유 조약", "마스트리히트 조약", "올림픽 헌장"],
    answer: "지속가능발전목표(SDGs)", explanation: "SDGs는 빈곤 퇴치, 기후변화 대응 등 지구의 지속가능성을 위한 UN의 17개 목표입니다."
  },
  {
    id: "g56_mc_30", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "multiple_choice", difficulty: "중", base_score: 3,
    question: "우리나라 해안선 중 리아스식 해안으로 섬과 만이 많아 갯벌이 세계적으로 발달한 바다는?",
    options: ["서해와 남해", "동해", "북해", "지중해"],
    answer: "서해와 남해", explanation: "서해와 남해는 조수간만의 차가 크고 해안선이 복잡하여 넓은 갯벌이 형성되었습니다."
  },

  // --- 5~6학년군 단답형 (20문항) ---
  {
    id: "g56_sa_01", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "대한민국 영토의 가장 동쪽 끝에 위치한 소중한 화산섬의 이름은 무엇일까요?",
    options: [], answer: "독도", explanation: "독도는 동도와 서도로 이루어진 대한민국의 아름다운 고유 영토입니다."
  },
  {
    id: "g56_sa_02", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "한 나라의 주권이 미치는 바다의 영역을 두 글자로 무엇이라고 부를까요?",
    options: [], answer: "영해", explanation: "영토 기준선으로부터 통상 12해리까지를 영해라고 부릅니다."
  },
  {
    id: "g56_sa_03", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "대한민국의 최고 법률이자 모든 법률의 제정 근거가 되는 기본법의 이름은?",
    options: [], answer: "헌법", explanation: "헌법은 국민의 기본권과 국가 통치 구조를 규정한 최고의 법입니다."
  },
  {
    id: "g56_sa_04", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "법률이 헌법에 합치하는지 판결하고 국민의 기본권 침해를 구제하는 헌법 수호 기관은?",
    options: [], answer: "헌법재판소", explanation: "헌법재판소는 9인의 재판관으로 구성된 최고 사법기관 중 하나입니다."
  },
  {
    id: "g56_sa_05", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "신석기 시대 사람들이 흙으로 빚어 겉면에 빗살 무늬를 새긴 대표적인 토기는?",
    options: [], answer: "빗살무늬 토기", explanation: "빗살무늬 토기는 신석기인의 식량 저장과 조리 기술을 증명합니다."
  },
  {
    id: "g56_sa_06", grade_group: "5~6학년군", unit_name: "유적과 유물로 살펴본 옛 사람들의 생활", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "고조선 시대에 지배자인 족장의 권력을 상징하는 거대한 바위 무덤 유적은 무엇일까요?",
    options: [], answer: "고인돌", explanation: "우리나라는 전 세계 고인돌의 절반 이상이 밀집된 고인돌 왕국입니다."
  },
  {
    id: "g56_sa_07", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "1443년 세종대왕이 백성을 위해 창제한 우리 글자의 원래 명칭은 무엇일까요?",
    options: [], answer: "훈민정음", explanation: "백성을 가르치는 바른 소리라는 뜻의 훈민정음이 오늘날의 한글입니다."
  },
  {
    id: "g56_sa_08", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "고려 시대 몽골의 침략을 부처님의 힘으로 물리치고자 해인사에 판각한 목판 경전은?",
    options: [], answer: "팔만대장경", explanation: "팔만대장경판은 유네스코 세계기록유산이자 고려 목판 인쇄술의 극치입니다."
  },
  {
    id: "g56_sa_09", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "1919년 3월 1일 서울 탑골공원에서 시작되어 전국으로 번진 거족적 독립 만세 운동은?",
    options: [], answer: "3·1 운동", explanation: "3·1 만세 운동은 우리 민족의 자주독립 의지를 세계만방에 알렸습니다."
  },
  {
    id: "g56_sa_10", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "백범 김구 선생이 주석을 맡아 광복군을 창설하고 독립 투쟁을 이끈 상하이의 망명정부는?",
    options: [], answer: "대한민국 임시정부", explanation: "대한민국 임시정부는 오늘날 대한민국 헌정사의 법통을 잇는 뿌리입니다."
  },
  {
    id: "g56_sa_11", grade_group: "5~6학년군", unit_name: "평화 통일을 위한 노력, 민주화와 산업화", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "1960년 3·15 부정선거에 항거하여 독재를 무너뜨린 민주주의 혁명은 무엇일까요?",
    options: [], answer: "4·19 혁명", explanation: "4·19 혁명은 민주주의를 지켜낸 아시아 최초의 성공한 시민 혁명입니다."
  },
  {
    id: "g56_sa_12", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "국가의 권력을 입법부(국회), 행정부(정부), 사법부(법원)로 나누는 원리는 무엇일까요?",
    options: [], answer: "삼권분립", explanation: "삼권분립은 권력 남용을 방지하고 상호 견제와 균형을 이루는 핵심 원리입니다."
  },
  {
    id: "g56_sa_13", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "선거에서 유권자가 누구를 뽑았는지 다른 사람이 알지 못하도록 보장하는 선거 원칙은?",
    options: [], answer: "비밀 선거", explanation: "비밀 선거는 압력이나 강요 없이 자유롭게 투표할 수 있도록 보장합니다."
  },
  {
    id: "g56_sa_14", grade_group: "5~6학년군", unit_name: "지구, 대륙 그리고 국가들", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "지구를 북반구와 남반구로 정확히 절반씩 나누는 기준선으로 위도 0도인 가상의 선은?",
    options: [], answer: "적도", explanation: "적도는 태양열을 가장 많이 받는 지구 중심의 가상 위선입니다."
  },
  {
    id: "g56_sa_15", grade_group: "5~6학년군", unit_name: "지구, 대륙 그리고 국가들", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "영국 그리니치 천문대를 지나는 경도의 기준선(경도 0도)을 무엇이라고 부를까요?",
    options: [], answer: "본초자오선", explanation: "본초자오선은 전 세계 시간대(Time Zone)와 동경·서경을 나누는 기준입니다."
  },
  {
    id: "g56_sa_16", grade_group: "5~6학년군", unit_name: "세계의 자연환경", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "연중 비가 거의 오지 않아 모래언덕과 오아시스가 나타나는 건조한 지형을 무엇이라 할까요?",
    options: [], answer: "사막", explanation: "사막은 연 강수량이 250mm 이하로 매우 메마른 건조 지형입니다."
  },
  {
    id: "g56_sa_17", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "우리나라에서 만든 자동차나 반도체를 다른 나라로 파는 무역 활동을 무엇이라 할까요?",
    options: [], answer: "수출", explanation: "국내 생산물을 외국 시장에 내다 파는 활동을 수출이라고 합니다."
  },
  {
    id: "g56_sa_18", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "외국에서 생산된 석유나 농산물을 우리나라로 사들이는 경제 활동은 무엇일까요?",
    options: [], answer: "수입", explanation: "국내에 부족한 자원과 상품을 외국에서 들여오는 활동을 수입이라고 합니다."
  },
  {
    id: "g56_sa_19", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "short_answer", difficulty: "하", base_score: 1,
    question: "세계 평화와 안전을 유지하기 위해 1945년에 창설된 국제 연합의 영어 약칭은?",
    options: [], answer: "UN", explanation: "UN(United Nations)은 190여 개국이 가입한 범세계적 국제기구입니다."
  },
  {
    id: "g56_sa_20", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "short_answer", difficulty: "중", base_score: 3,
    question: "내가 속한 나라를 넘어 전 지구적 환경과 평화에 책임감을 갖고 연대하는 시민 의식은?",
    options: [], answer: "세계시민의식", explanation: "지구촌 공동체의 일원으로서 인류의 공존을 추구하는 정신을 세계시민의식이라 합니다."
  },

  // --- 5~6학년군 서술형 (10문항) ---
  {
    id: "g56_desc_01", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "국가 권력을 국회(입법), 행정부(행정), 법원(사법)으로 나누는 '삼권분립'이 필요한 까닭을 쓰세요.",
    options: [], answer: "한 기관이나 사람에게 권력이 집중되는 독재를 막고, 서로 견제하고 균형을 이루어 국민의 자유와 권리를 보호하기 위해서입니다.",
    grading_keywords: ["독재", "집중", "견제", "균형", "권리", "자유", "보호"],
    explanation: "권력 집중을 방지하고 상호 견제를 통해 국민 주권과 민주주의를 지키기 위해 삼권분립이 존재합니다."
  },
  {
    id: "g56_desc_02", grade_group: "5~6학년군", unit_name: "우리나라 국토 여행", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "독도가 역사적, 지리적으로 대한민국의 고유한 영토인 까닭을 1~2문장으로 서술하세요.",
    options: [], answer: "신라 지증왕 때 이사부가 우산국을 복속한 이래 수많은 역사 기록에 우리 영토로 기록되어 있고, 울릉도에서 눈으로 보이는 가장 가까운 섬이기 때문입니다.",
    grading_keywords: ["신라", "이사부", "울릉도", "역사", "기록", "지리", "주권"],
    explanation: "독도는 세종실록지리지 등 공적 기록과 주민 거주, 실효적 지배를 통해 명백한 대한민국의 고유 영토입니다."
  },
  {
    id: "g56_desc_03", grade_group: "5~6학년군", unit_name: "민주주의와 시민 참여", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "민주 선거의 4대 원칙 중 '보통 선거'와 '평등 선거'의 차이점을 설명하세요.",
    options: [], answer: "보통 선거는 성별이나 재산에 상관없이 일정 나이가 되면 누구나 투표하는 것이고, 평등 선거는 누구나 표의 가치가 동등하게 1인 1표를 갖는 것입니다.",
    grading_keywords: ["나이", "누구나", "1표", "가치", "동등", "차별"],
    explanation: "보통 선거는 선거권 부여의 자격 기준이며, 평등 선거는 표의 실질적 가치 균등을 의미합니다."
  },
  {
    id: "g56_desc_04", grade_group: "5~6학년군", unit_name: "달라지는 시대, 변화하는 생활 모습", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "세종대왕이 훈민정음(한글)을 창제한 까닭을 당시 백성들의 처지와 연관 지어 서술하세요.",
    options: [], answer: "어려운 한자를 몰라 억울한 일을 당하는 백성들을 불쌍히 여겨, 누구나 쉽게 배워 뜻을 펼칠 수 있게 하기 위해서였습니다.",
    grading_keywords: ["한자", "어려", "백성", "억울", "쉽게", "배워", "애민"],
    explanation: "한자의 어려움으로 인한 문해력 격차를 해소하고 백성의 소통을 돕기 위해 창제한 위대한 문자입니다."
  },
  {
    id: "g56_desc_05", grade_group: "5~6학년군", unit_name: "법과 인권의 보장", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "모든 인간이 태어나면서부터 누리는 '인권'이 국가 권력보다 앞서 보장되어야 하는 까닭은?",
    options: [], answer: "인간은 그 자체로 존엄한 존재이며, 인권은 국가가 만들어준 것이 아니라 빼앗길 수 없는 태어날 때부터의 권리이기 때문입니다.",
    grading_keywords: ["존엄", "태어나", "천부", "빼앗", "행복", "기본"],
    explanation: "인권은 헌법 이전의 천부적 권리이며 국가는 이를 침해하지 않고 최대한 보장할 의무가 있습니다."
  },
  {
    id: "g56_desc_06", grade_group: "5~6학년군", unit_name: "시장경제와 국가 간 거래", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "국가 간에 무역(수출과 수입)을 하는 까닭을 각 나라의 자원 및 기술 차이와 연관 지어 쓰세요.",
    options: [], answer: "나라마다 자연환경과 기술이 달라 생산할 수 있는 물건이 다르므로, 각자 잘 만드는 것을 거래하여 서로 이익을 얻기 위해서입니다.",
    grading_keywords: ["자원", "기술", "환경", "다르", "특화", "이익", "교환"],
    explanation: "비교우위와 자원의 불균등 분포로 인해 상호 무역을 통해 전 세계가 효율성과 풍요를 누립니다."
  },
  {
    id: "g56_desc_07", grade_group: "5~6학년군", unit_name: "지구촌 사람들", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "전 지구적인 '기후위기(지구온난화)'를 해결하기 위해 전 세계 국가가 협력해야 하는 까닭은?",
    options: [], answer: "온실가스와 환경 파괴는 국경을 넘어 전 지구에 피해를 주므로, 한 나라의 노력만으로는 해결할 수 없기 때문입니다.",
    grading_keywords: ["국경", "온실가스", "지구", "공동", "한 나라", "협력", "연대"],
    explanation: "지구 생태계는 하나로 연결되어 있으므로 모든 국가와 시민이 탄소 배출 저감에 함께 동참해야 합니다."
  },
  {
    id: "g56_desc_08", grade_group: "5~6학년군", unit_name: "식민 통치와 저항, 전쟁이 바꾼 사회와 생활", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "3·1 만세 운동이 국내외 독립운동에 미친 역사적 의의를 1~2문장으로 쓰세요.",
    options: [], answer: "대한민국 임시정부 수립의 계기가 되었으며, 중국의 5·4 운동 등 아시아 민족 해방 운동에도 큰 영향을 주었습니다.",
    grading_keywords: ["임시정부", "수립", "단결", "5·4", "아시아", "평화", "영향"],
    explanation: "3·1 운동은 전 민족의 독립 의지를 응집시켜 임시정부를 탄생시킨 현대 민주공화국의 출발점입니다."
  },
  {
    id: "g56_desc_09", grade_group: "5~6학년군", unit_name: "우리나라 지리 탐구", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "수도권에 인구와 일자리가 지나치게 집중되는 것을 막고 '국토 균형 발전'을 이루어야 하는 까닭은?",
    options: [], answer: "수도권은 집값 상승과 교통 체증으로 고통받고, 지방은 인구 감소로 소멸 위기에 처하므로 고른 발전이 필요하기 때문입니다.",
    grading_keywords: ["수도권", "집중", "지방", "소멸", "불균형", "교통", "균형"],
    explanation: "수도권 과밀의 폐해와 지역 간 격차를 해소하여 전국 어디서나 국민이 고루 행복을 누리게 하기 위함입니다."
  },
  {
    id: "g56_desc_10", grade_group: "5~6학년군", unit_name: "평화 통일을 위한 노력, 민주화와 산업화", question_type: "descriptive", difficulty: "상", base_score: 5,
    question: "우리가 남북 평화 통일을 이루어야 하는 까닭을 이산가족과 국력 발전의 측면에서 서술하세요.",
    options: [], answer: "분단으로 인한 이산가족의 오랜 고통을 치유하고, 전쟁 위협을 없애 국방비 낭비를 줄이고 경제를 비약적으로 발전시키기 위해서입니다.",
    grading_keywords: ["이산가족", "전쟁", "평화", "국방비", "경제", "발전", "고통"],
    explanation: "인도주의적 아픔을 치유하고 유라시아 대륙으로 뻗어나가는 평화 번영의 한반도를 만들기 위해 통일이 필요합니다."
  }
];

// 전역 스코프에 노출 (index.html에서 즉시 참조 가능)
if (typeof window !== "undefined") {
  window.SOCIAL_QUESTION_BANK_ALL = SOCIAL_QUESTION_BANK_ALL;
}
